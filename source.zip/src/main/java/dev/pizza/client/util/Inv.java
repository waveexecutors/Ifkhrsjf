package dev.pizza.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

public final class Inv {
    private Inv() {}

    public static int find(java.util.function.Predicate<ItemStack> pred) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return -1;
        Inventory inv = mc.player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (!s.isEmpty() && pred.test(s)) return i;
        }
        return -1;
    }

    public static int findHotbar(java.util.function.Predicate<ItemStack> pred) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return -1;
        Inventory inv = mc.player.getInventory();
        for (int i = 0; i < 9; i++) {
            ItemStack s = inv.getItem(i);
            if (!s.isEmpty() && pred.test(s)) return i;
        }
        return -1;
    }
}
