package dev.pizza.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/**
 * Premium dark palette inspired by high-end paid clients.
 * Accent is a warm pizza orange for brand identity.
 */
public final class Draw {
    public static final int ACCENT      = 0xFFFF6B35; // pizza orange
    public static final int ACCENT_DARK = 0xFFCC4A1A;
    public static final int ACCENT_GLOW = 0x40FF6B35;
    public static final int HEADER      = 0xFF0D0D12;
    public static final int BODY        = 0xF00A0A0F;
    public static final int TRACK       = 0xFF1A1A24;
    public static final int TEXT        = 0xFFF1F1F4;
    public static final int DIM         = 0xFF8B8B9A;
    public static final int SUCCESS     = 0xFF4ADE80;
    public static final int DANGER      = 0xFFEF4444;

    private Draw() {}

    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int r = (int) (ar * (1 - t) + br * t);
        int g = (int) (ag * (1 - t) + bg * t);
        int bl = (int) (ab * (1 - t) + bb * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    public static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    public static void text(GuiGraphics g, String s, int x, int y, int color) {
        g.drawString(Minecraft.getInstance().font, s, x, y, color);
    }

    public static int width(String s) {
        return Minecraft.getInstance().font.width(s);
    }

    public static void hudBox(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, 0xCC0A0A0F);
        g.fill(x, y, x + 2, y + h, ACCENT);
        // subtle top line
        g.fill(x + 2, y, x + w, y + 1, 0x33FFFFFF);
    }

    public static void panelShadow(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x - 2, y - 2, x + w + 2, y + h + 2, 0x50000000);
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0x80000000);
    }

    public static String pretty(String path) {
        StringBuilder sb = new StringBuilder();
        for (String part : path.split("_")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }
}
