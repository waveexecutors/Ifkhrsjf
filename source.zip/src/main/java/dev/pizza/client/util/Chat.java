package dev.pizza.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

public final class Chat {
    private Chat() {}

    public static void info(String msg) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            mc.player.displayClientMessage(Component.literal("§6[Pizza] §f" + msg), false);
        }
    }

    public static String dimension() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return "unknown";
        ResourceKey<Level> key = mc.level.dimension();
        String path = key.location().getPath();
        return path;
    }
}
