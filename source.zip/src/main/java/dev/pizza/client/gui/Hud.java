package dev.pizza.client.gui;

import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Features;
import dev.pizza.client.features.EspFeature;
import dev.pizza.client.features.HudFeature;
import dev.pizza.client.features.TracersFeature;
import dev.pizza.client.util.Draw;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public final class Hud {
    private Hud() {}

    public static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        // left column: per-feature overlays
        int y = 4;
        for (Feature f : Features.ALL) {
            if (f.enabled) y += f.hud(g, 4, y);
        }

        // ESP + Tracers (full screen)
        if (EspFeature.I != null && EspFeature.I.enabled) {
            EspFeature.I.renderEsp(g);
        }
        if (TracersFeature.I != null && TracersFeature.I.enabled) {
            TracersFeature.I.renderTracers(g);
        }

        // right column: premium arraylist
        if (HudFeature.I != null && HudFeature.I.enabled && HudFeature.I.arraylist.value) {
            int sw = mc.getWindow().getGuiScaledWidth();
            List<String> lines = new ArrayList<>();
            for (Feature f : Features.ALL) {
                if (!f.enabled || f instanceof HudFeature) continue;
                String info = f.info();
                lines.add(info == null ? f.name : f.name + " §7" + info);
            }
            lines.sort(Comparator.comparingInt((String s) -> Draw.width(s)).reversed());
            int ry = 4;
            for (String s : lines) {
                int w = Draw.width(s);
                // dark pill with accent bar
                g.fill(sw - w - 10, ry, sw - 2, ry + 12, 0xCC0A0A0F);
                g.fill(sw - 2, ry, sw, ry + 12, Draw.ACCENT);
                g.fill(sw - w - 10, ry, sw - w - 9, ry + 12, 0x33FFFFFF);
                Draw.text(g, s, sw - w - 7, ry + 2, Draw.TEXT);
                ry += 13;
            }
        }
    }
}
