package dev.pizza.client.gui;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Features;
import dev.pizza.client.feature.Setting;
import dev.pizza.client.util.Draw;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/**
 * Premium Vape-inspired ClickGUI.
 * Dark panels, smooth animations, accent orange, clean typography.
 * Right Shift to open / close. Drag headers, right-click settings.
 */
public class ClickGui extends Screen {
    private static final int PW = 148, HH = 22, RH = 18, BR = 16, NR = 26;

    public static final Map<String, int[]> LAYOUT = new LinkedHashMap<>();
    private static final List<Panel> PANELS = new ArrayList<>();
    private static final Set<Feature> EXPANDED = new HashSet<>();
    private static final Map<Feature, Float> ANIM = new HashMap<>();

    private static final class Panel {
        final Category cat;
        int x, y;
        boolean open;

        Panel(Category cat, int x, int y, boolean open) {
            this.cat = cat;
            this.x = x;
            this.y = y;
            this.open = open;
        }
    }

    private boolean pl, pr, prs;
    private Panel drag;
    private int dox, doy;
    private Setting.Num slider;
    private int sliderX, sliderW;

    public ClickGui() {
        super(Component.literal("Pizza Client"));
        long w = GLFW.glfwGetCurrentContext();
        pl = GLFW.glfwGetMouseButton(w, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        pr = GLFW.glfwGetMouseButton(w, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        prs = GLFW.glfwGetKey(w, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        ensurePanels();
    }

    private static void ensurePanels() {
        if (!PANELS.isEmpty()) return;
        int i = 0;
        for (Category c : Category.values()) {
            if (Features.byCategory(c).isEmpty()) continue;
            int[] d = LAYOUT.get(c.name());
            if (d != null) PANELS.add(new Panel(c, d[0], d[1], d[2] == 1));
            else PANELS.add(new Panel(c, 18 + i * (PW + 12), 36, true));
            i++;
        }
    }

    public static void syncLayout() {
        for (Panel p : PANELS) LAYOUT.put(p.cat.name(), new int[] {p.x, p.y, p.open ? 1 : 0});
    }

    private static int rowH(Setting s) {
        return s instanceof Setting.Num ? NR : BR;
    }

    private int panelH(Panel p) {
        int h = HH;
        if (!p.open) return h;
        for (Feature f : Features.byCategory(p.cat)) {
            h += RH;
            if (EXPANDED.contains(f)) for (Setting s : f.settings) h += rowH(s);
        }
        return h + 3;
    }

    private void closeGui() {
        Features.save();
        Minecraft.getInstance().setScreen(null);
    }

    public boolean isPauseScreen() {
        return false;
    }

    public void removed() {
        Features.save();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        long win = GLFW.glfwGetCurrentContext();
        boolean l = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean rs = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        boolean lClick = l && !pl;
        boolean rClick = r && !pr;
        pl = l;
        pr = r;
        if (rs && !prs) {
            closeGui();
            return;
        }
        prs = rs;

        // dim background
        g.fill(0, 0, width, height, 0x99000000);

        // top brand bar
        String title = "PIZZA CLIENT  §7|  §fRight Shift to close  §7|  §fL-click toggle · R-click settings";
        int tw = Draw.width(title);
        g.fill((width - tw) / 2 - 12, 6, (width + tw) / 2 + 12, 22, 0xE00A0A0F);
        g.fill((width - tw) / 2 - 12, 21, (width + tw) / 2 + 12, 22, Draw.ACCENT);
        Draw.text(g, title, (width - tw) / 2, 10, Draw.TEXT);

        Panel top = null;
        for (int i = PANELS.size() - 1; i >= 0; i--) {
            Panel p = PANELS.get(i);
            if (Draw.inside(mx, my, p.x, p.y, PW, panelH(p))) {
                top = p;
                break;
            }
        }
        if (top != null && (lClick || rClick)) {
            PANELS.remove(top);
            PANELS.add(top);
        }

        if (!l) {
            drag = null;
            slider = null;
        }
        if (drag != null) {
            drag.x = Math.max(0, Math.min(width - PW, mx - dox));
            drag.y = Math.max(0, Math.min(height - HH, my - doy));
        }
        if (slider != null) {
            double t = (mx - sliderX) / (double) sliderW;
            slider.set(slider.min + t * (slider.max - slider.min));
        }

        Feature hovered = null;
        for (Panel p : new ArrayList<>(PANELS)) {
            boolean act = p == top;
            int h = panelH(p);

            // shadow + body
            Draw.panelShadow(g, p.x, p.y, PW, h);
            g.fill(p.x, p.y, p.x + PW, p.y + HH, Draw.HEADER);
            // accent underline
            g.fill(p.x, p.y + HH - 2, p.x + PW, p.y + HH, Draw.ACCENT);
            // subtle left edge
            g.fill(p.x, p.y, p.x + 2, p.y + HH, Draw.ACCENT);

            Draw.text(g, p.cat.label.toUpperCase(), p.x + 10, p.y + 7, Draw.TEXT);
            Draw.text(g, p.open ? "—" : "+", p.x + PW - 14, p.y + 7, Draw.DIM);

            if (act && Draw.inside(mx, my, p.x, p.y, PW, HH)) {
                if (lClick) {
                    drag = p;
                    dox = mx - p.x;
                    doy = my - p.y;
                } else if (rClick) {
                    p.open = !p.open;
                }
            }
            if (!p.open) continue;

            g.fill(p.x, p.y + HH, p.x + PW, p.y + h, Draw.BODY);
            int ry = p.y + HH;

            for (Feature f : Features.byCategory(p.cat)) {
                boolean hov = act && Draw.inside(mx, my, p.x, ry, PW, RH);
                float a = ANIM.getOrDefault(f, f.enabled ? 1f : 0f);
                a += ((f.enabled ? 1f : 0f) - a) * 0.28f;
                ANIM.put(f, a);

                if (hov) {
                    hovered = f;
                    g.fill(p.x + 2, ry, p.x + PW, ry + RH, 0x18FFFFFF);
                    if (lClick) {
                        f.toggle();
                        if (f.enabled) f.onToggledByUser();
                    } else if (rClick && !f.settings.isEmpty()) {
                        if (!EXPANDED.remove(f)) EXPANDED.add(f);
                    }
                }

                // left accent bar when enabled
                if (a > 0.04f) {
                    g.fill(p.x, ry, p.x + 2, ry + RH, Draw.lerp(0xFF1A1A24, Draw.ACCENT, a));
                }

                Draw.text(g, f.name, p.x + 10, ry + 5, Draw.lerp(Draw.DIM, 0xFFFFFFFF, a));

                if (!f.settings.isEmpty()) {
                    Draw.text(g, EXPANDED.contains(f) ? "▾" : "···", p.x + PW - 42, ry + 5, Draw.DIM);
                }

                // modern toggle switch
                int sx = p.x + PW - 28, sy = ry + 5;
                g.fill(sx, sy, sx + 20, sy + 9, Draw.lerp(Draw.TRACK, Draw.ACCENT_DARK, a));
                int kx = sx + 1 + Math.round(a * 11f);
                g.fill(kx, sy + 1, kx + 7, sy + 8, 0xFFFFFFFF);

                ry += RH;

                if (EXPANDED.contains(f)) {
                    for (Setting s : f.settings) {
                        int sh = rowH(s);
                        g.fill(p.x + 2, ry, p.x + PW, ry + sh, 0x30000000);
                        g.fill(p.x + 4, ry + 1, p.x + 5, ry + sh - 1, Draw.ACCENT_DARK);
                        boolean shov = act && Draw.inside(mx, my, p.x, ry, PW, sh);
                        if (shov) g.fill(p.x + 5, ry, p.x + PW, ry + sh, 0x12FFFFFF);

                        if (s instanceof Setting.Bool b) {
                            Draw.text(g, b.name, p.x + 12, ry + 4, Draw.TEXT);
                            int bx = p.x + PW - 18;
                            g.fill(bx, ry + 3, bx + 10, ry + 13, Draw.TRACK);
                            if (b.value) g.fill(bx + 2, ry + 5, bx + 8, ry + 11, Draw.ACCENT);
                            if (shov && lClick) b.toggle();
                        } else if (s instanceof Setting.Num n) {
                            Draw.text(g, n.name, p.x + 12, ry + 3, Draw.TEXT);
                            String v = n.text();
                            Draw.text(g, v, p.x + PW - 10 - Draw.width(v), ry + 3, Draw.DIM);
                            int bx = p.x + 12, bw = PW - 24;
                            g.fill(bx, ry + 17, bx + bw, ry + 20, Draw.TRACK);
                            int fw = (int) Math.round((n.value - n.min) / (n.max - n.min) * bw);
                            g.fill(bx, ry + 17, bx + fw, ry + 20, Draw.ACCENT);
                            g.fill(bx + Math.max(0, fw - 2), ry + 15, bx + fw + 2, ry + 22, 0xFFFFFFFF);
                            if (shov && lClick) {
                                slider = n;
                                sliderX = bx;
                                sliderW = bw;
                            }
                        } else if (s instanceof Setting.Button bt) {
                            Draw.text(g, bt.label.get(), p.x + 12, ry + 4, Draw.ACCENT);
                            if (shov && lClick) bt.action.run();
                        }
                        ry += sh;
                    }
                }
            }
        }

        if (hovered != null) {
            String d = hovered.description;
            int dtw = Draw.width(d) + 12;
            int tx = Math.min(mx + 12, width - dtw - 4);
            int ty = my + 14;
            g.fill(tx, ty, tx + dtw, ty + 16, 0xF00A0A0F);
            g.fill(tx, ty, tx + 2, ty + 16, Draw.ACCENT);
            Draw.text(g, d, tx + 6, ty + 4, Draw.TEXT);
        }
    }
}
