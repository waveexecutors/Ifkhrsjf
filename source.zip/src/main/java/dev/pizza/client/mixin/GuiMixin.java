package dev.pizza.client.mixin;

import dev.pizza.client.gui.Hud;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Gui.class)
public class GuiMixin {

    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void pizza$hud(GuiGraphics graphics, DeltaTracker deltaTracker, CallbackInfo ci) {
        Hud.render(graphics);
    }
}
