package dev.pizza.client.mixin;

import dev.pizza.client.features.XrayFeature;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Full-face Xray: hidden blocks never render, never occlude, and never cull
 * neighbor faces so ores stay visible from every angle.
 */
@Mixin(BlockBehaviour.BlockStateBase.class)
public class BlockStateBaseMixin {

    @Inject(method = "getRenderShape", at = @At("HEAD"), cancellable = true, require = 0)
    private void pizza$renderShape(CallbackInfoReturnable<RenderShape> cir) {
        if (XrayFeature.isHidden((BlockState) (Object) this)) {
            cir.setReturnValue(RenderShape.INVISIBLE);
        }
    }

    @Inject(method = "canOcclude", at = @At("HEAD"), cancellable = true, require = 0)
    private void pizza$canOcclude(CallbackInfoReturnable<Boolean> cir) {
        if (XrayFeature.active) {
            // Nothing occludes while xray is on – all faces of visible blocks draw
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "isSolidRender", at = @At("HEAD"), cancellable = true, require = 0)
    private void pizza$solidRender(CallbackInfoReturnable<Boolean> cir) {
        if (XrayFeature.isHidden((BlockState) (Object) this)) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "skipRendering", at = @At("HEAD"), cancellable = true, require = 0)
    private void pizza$skipRendering(BlockState neighbor, Direction dir, CallbackInfoReturnable<Boolean> cir) {
        if (XrayFeature.active) {
            // Never skip faces between blocks while xray is active
            cir.setReturnValue(false);
        }
    }
}
