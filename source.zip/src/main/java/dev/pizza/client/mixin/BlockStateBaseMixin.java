package dev.pizza.client.mixin;

import dev.pizza.client.features.XrayFeature;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BlockBehaviour.BlockStateBase.class)
public class BlockStateBaseMixin {

    @Inject(method = "getRenderShape", at = @At("HEAD"), cancellable = true, require = 0)
    private void pizza$renderShape(CallbackInfoReturnable<RenderShape> cir) {
        if (XrayFeature.isHidden((BlockState) (Object) this)) {
            cir.setReturnValue(RenderShape.INVISIBLE);
        }
    }

    @Inject(method = "canOcclude", at = @At("HEAD"), cancellable = true, require = 0)
    private void pizza$canOcclude(CallbackInfoReturnable<Boolean> cir) {
        if (XrayFeature.isHidden((BlockState) (Object) this)) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "isSolidRender", at = @At("HEAD"), cancellable = true, require = 0)
    private void pizza$solidRender(CallbackInfoReturnable<Boolean> cir) {
        if (XrayFeature.isHidden((BlockState) (Object) this)) {
            cir.setReturnValue(false);
        }
    }
}
