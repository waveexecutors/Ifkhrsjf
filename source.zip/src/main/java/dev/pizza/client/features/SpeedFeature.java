package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import net.minecraft.world.phys.Vec3;

/** Simple ground speed boost. Keep values modest for stability. */
public class SpeedFeature extends Feature {
    private final Setting.Num multiplier = num("Multiplier", 1.25, 1.0, 2.5, 0.05);
    private final Setting.Bool onlyGround = bool("Only On Ground", true);
    private final Setting.Bool autoSprint = bool("Auto Sprint", true);

    public SpeedFeature() {
        super("Speed", "Increases horizontal movement speed. Tune the multiplier per server.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.player.getAbilities().flying || mc.player.isPassenger()) return;
        if (onlyGround.value && !mc.player.onGround()) return;

        float fx = mc.player.input.getMoveVector().x;
        float fz = mc.player.input.getMoveVector().y;
        if (fx == 0 && fz == 0) return;

        if (autoSprint.value && !mc.player.isSprinting()) mc.player.setSprinting(true);

        float yaw = mc.player.getYRot() * 0.017453292f;
        double len = Math.sqrt(fx * fx + fz * fz);
        if (len > 0.01) { fx /= len; fz /= len; }

        double boost = 0.06 * (multiplier.value - 1.0);
        double mx = (fz * -Math.sin(yaw) + fx * Math.cos(yaw)) * boost;
        double mz = (fz * Math.cos(yaw) + fx * Math.sin(yaw)) * boost;
        Vec3 v = mc.player.getDeltaMovement();
        mc.player.setDeltaMovement(v.x + mx, v.y, v.z + mz);
    }

    @Override
    public String info() {
        return String.format("%.2fx", multiplier.value);
    }
}
