package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.util.Chat;
import dev.pizza.client.util.Draw;
import net.minecraft.client.gui.GuiGraphics;

public class DeathCoordsFeature extends Feature {
    private int dx, dy, dz;
    private boolean has = false;
    private String dim = "";

    public DeathCoordsFeature() {
        super("DeathCoords", "Saves and displays the coordinates of your last death.", Category.PLAYER);
        enabled = true;
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.player.isDeadOrDying() && !has) {
            dx = (int) Math.floor(mc.player.getX());
            dy = (int) Math.floor(mc.player.getY());
            dz = (int) Math.floor(mc.player.getZ());
            dim = Chat.dimension();
            has = true;
            Chat.info("Death recorded: " + dx + " " + dy + " " + dz + " (" + dim + ")");
        }
        if (!mc.player.isDeadOrDying() && mc.player.getHealth() > 0) {
            // keep last death
        }
    }

    @Override
    public int hud(GuiGraphics g, int x, int y) {
        if (!has) return 0;
        String l = "Death  " + dx + "  " + dy + "  " + dz + "  §7" + dim;
        int w = Draw.width(l) + 10;
        Draw.hudBox(g, x, y, w, 14);
        Draw.text(g, l, x + 5, y + 3, Draw.DANGER);
        return 18;
    }
}
