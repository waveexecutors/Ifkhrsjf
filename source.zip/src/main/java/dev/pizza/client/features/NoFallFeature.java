package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;

/** Softens fall damage by zeroing fall distance before impact when safe. */
public class NoFallFeature extends Feature {
    private final Setting.Num minFall = num("Min Fall Distance", 3.0, 2.0, 10.0, 0.5);

    public NoFallFeature() {
        super("NoFall", "Prevents fall damage by resetting fall distance before landing.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.player.fallDistance > minFall.value && mc.player.getDeltaMovement().y < -0.1) {
            // approaching ground – clear fall distance
            if (!mc.player.onGround()) {
                mc.player.fallDistance = 0f;
            }
        }
    }
}
