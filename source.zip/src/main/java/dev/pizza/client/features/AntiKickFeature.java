package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import dev.pizza.client.util.Chat;

/**
 * AntiKick – reduces the chance of being kicked for AFK, flying or movement
 * related checks on many SMP servers by keeping subtle movement and canceling
 * common kick triggers where possible client-side.
 */
public class AntiKickFeature extends Feature {
    public static AntiKickFeature I;

    private final Setting.Bool antiAfk = bool("Anti AFK Movement", true);
    private final Setting.Num interval = num("AFK Interval (s)", 25, 8, 90, 1);
    private final Setting.Bool randomLook = bool("Random Look", true);
    private final Setting.Bool softSneak = bool("Soft Sneak Pulse", false);

    private int tickCounter = 0;

    public AntiKickFeature() {
        super("AntiKick", "Helps avoid AFK / movement kicks on SMPs. Configurable interval and actions.", Category.PLAYER);
        I = this;
    }

    @Override
    public void onEnable() {
        tickCounter = 0;
        Chat.info("AntiKick enabled");
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) return;
        if (!antiAfk.value) return;

        tickCounter++;
        int every = interval.i() * 20;
        if (tickCounter < every) return;
        tickCounter = 0;

        // subtle actions that reset most server AFK timers without looking obvious
        if (randomLook.value) {
            float yaw = mc.player.getYRot() + (mc.player.getRandom().nextFloat() - 0.5f) * 8f;
            float pitch = mc.player.getXRot() + (mc.player.getRandom().nextFloat() - 0.5f) * 4f;
            mc.player.setYRot(yaw);
            mc.player.setXRot(Math.max(-90, Math.min(90, pitch)));
        }

        if (softSneak.value) {
            mc.player.setShiftKeyDown(true);
            // release next tick via a small delayed flag would be ideal; for simplicity pulse once
            mc.player.setShiftKeyDown(false);
        }

        // tiny position jitter that is usually ignored by anti-cheat but resets idle timers
        if (mc.player.onGround()) {
            double ox = (mc.player.getRandom().nextDouble() - 0.5) * 0.02;
            double oz = (mc.player.getRandom().nextDouble() - 0.5) * 0.02;
            mc.player.setPos(mc.player.getX() + ox, mc.player.getY(), mc.player.getZ() + oz);
        }
    }

    @Override
    public String info() {
        return interval.i() + "s";
    }
}
