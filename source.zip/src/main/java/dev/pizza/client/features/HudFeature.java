package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import dev.pizza.client.util.Chat;
import dev.pizza.client.util.Draw;
import net.minecraft.client.gui.GuiGraphics;

public class HudFeature extends Feature {
    public static HudFeature I;
    public final Setting.Bool arraylist = bool("Arraylist", true);
    public final Setting.Bool coords = bool("Coordinates", true);
    public final Setting.Bool watermark = bool("Watermark", true);
    public final Setting.Bool fps = bool("FPS Counter", true);

    public HudFeature() {
        super("HUD", "Premium arraylist, coordinates, watermark and FPS. Fully configurable.", Category.MISC);
        I = this;
        enabled = true;
    }

    @Override
    public int hud(GuiGraphics g, int x, int y) {
        int used = 0;
        if (watermark.value) {
            String wm = "Pizza Client §7v2.0";
            int w = Draw.width(wm) + 12;
            Draw.hudBox(g, x, y, w, 14);
            Draw.text(g, wm, x + 5, y + 3, Draw.ACCENT);
            used += 18;
            y += 18;
        }
        if (fps.value && mc.getFps() > 0) {
            String f = "FPS  " + mc.getFps();
            int w = Draw.width(f) + 10;
            Draw.hudBox(g, x, y, w, 14);
            Draw.text(g, f, x + 5, y + 3, Draw.TEXT);
            used += 18;
            y += 18;
        }
        if (coords.value && mc.player != null) {
            int px = (int) Math.floor(mc.player.getX());
            int py = (int) Math.floor(mc.player.getY());
            int pz = (int) Math.floor(mc.player.getZ());
            String dim = Chat.dimension();
            String l1 = "XYZ  " + px + "  " + py + "  " + pz + "  " + mc.player.getDirection().getName();
            String l2 = null;
            if (dim.equals("overworld")) l2 = "Nether  " + Math.floorDiv(px, 8) + "  " + Math.floorDiv(pz, 8);
            else if (dim.equals("the_nether")) l2 = "Overworld  " + px * 8 + "  " + pz * 8;
            int w = Draw.width(l1) + 10;
            if (l2 != null) w = Math.max(w, Draw.width(l2) + 10);
            int h = l2 != null ? 25 : 14;
            Draw.hudBox(g, x, y, w, h);
            Draw.text(g, l1, x + 5, y + 3, Draw.TEXT);
            if (l2 != null) Draw.text(g, l2, x + 5, y + 14, Draw.DIM);
            used += h + 4;
        }
        return used;
    }
}
