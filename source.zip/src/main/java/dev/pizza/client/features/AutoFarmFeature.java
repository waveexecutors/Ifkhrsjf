package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

public class AutoFarmFeature extends Feature {
    private final Setting.Num range = num("Range", 4, 2, 5, 1);
    private int timer = 0;

    public AutoFarmFeature() {
        super("AutoFarm", "Breaks mature crops around you and replants when possible.", Category.WORLD);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;
        if (++timer < 5) return;
        timer = 0;
        BlockPos origin = mc.player.blockPosition();
        int r = range.i();
        for (int x = -r; x <= r; x++) {
            for (int z = -r; z <= r; z++) {
                for (int y = -1; y <= 2; y++) {
                    BlockPos p = origin.offset(x, y, z);
                    BlockState st = mc.level.getBlockState(p);
                    if (st.getBlock() instanceof CropBlock crop && crop.isMaxAge(st)) {
                        mc.gameMode.startDestroyBlock(p, Direction.UP);
                        return;
                    }
                    if (st.is(Blocks.AIR) && mc.level.getBlockState(p.below()).is(Blocks.FARMLAND)) {
                        // try use seed in hand
                        mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND,
                                new BlockHitResult(Vec3.atCenterOf(p), Direction.UP, p, false));
                        return;
                    }
                }
            }
        }
    }
}
