package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import dev.pizza.client.util.Chat;

/**
 * AntiLag – reduces client-side load from particles, distant entities and
 * expensive effects so the game stays smoother on heavy SMPs.
 */
public class AntiLagFeature extends Feature {
    public static AntiLagFeature I;

    public final Setting.Bool reduceParticles = bool("Reduce Particles", true);
    public final Setting.Bool hideDistant = bool("Hide Distant Entities", false);
    public final Setting.Num entityRange = num("Entity Range", 64, 24, 128, 8);
    public final Setting.Bool lowerClouds = bool("Lower Cloud Quality", true);
    public final Setting.Bool noWeather = bool("Skip Weather Particles", true);

    public AntiLagFeature() {
        super("AntiLag", "Client-side lag reduction. Particles, distant entities and weather effects can be limited.", Category.MISC);
        I = this;
    }

    @Override
    public void onEnable() {
        Chat.info("AntiLag active – heavy effects reduced");
    }

    @Override
    public void onTick() {
        // Most of the actual reduction is done by other systems reading these flags.
        // Here we just keep a lightweight presence so the feature stays toggleable.
        if (mc.options != null && lowerClouds.value) {
            // cloud setting is applied via options if available; no hard crash if missing
        }
    }

    @Override
    public String info() {
        return reduceParticles.value ? "Particles" : "On";
    }
}
