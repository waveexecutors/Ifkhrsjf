package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import java.util.HashSet;
import java.util.Set;

public class AutoSellFeature extends Feature {
    public static final Set<String> ITEMS = new HashSet<>();
    private final Setting.Num delay = num("Delay (s)", 30, 5, 120, 5);
    private int timer = 0;

    public AutoSellFeature() {
        super("AutoSell", "Periodically runs a sell command for configured items (SMP shops).", Category.PLAYER);
        button("Add held item", () -> "Add held", () -> {
            if (mc.player != null && !mc.player.getMainHandItem().isEmpty()) {
                String id = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(mc.player.getMainHandItem().getItem()).toString();
                ITEMS.add(id);
                dev.pizza.client.util.Chat.info("Added " + id);
            }
        });
        button("Clear list", () -> "Clear", ITEMS::clear);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.getConnection() == null) return;
        if (++timer < delay.i() * 20) return;
        timer = 0;
        if (ITEMS.isEmpty()) return;
        // common SMP sell commands – user can change in chat if needed
        mc.player.connection.sendCommand("sell all");
    }

    @Override
    public String info() {
        return ITEMS.size() + " items";
    }
}
