package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;

/**
 * Attempts to deal critical hits when attacking on ground by a tiny hop.
 * Simple client-side approach – no packet abuse.
 */
public class CriticalsFeature extends Feature {
    private final Setting.Bool onlyWhenMoving = bool("Only When Moving", false);
    private int cool = 0;

    public CriticalsFeature() {
        super("Criticals", "Tiny hop before attacks so hits register as criticals when possible.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.gameMode == null) return;
        if (cool > 0) { cool--; return; }
        if (!mc.player.onGround()) return;
        if (mc.player.isInWater() || mc.player.isInLava() || mc.player.isPassenger()) return;
        if (onlyWhenMoving.value && mc.player.input.getMoveVector().x == 0 && mc.player.input.getMoveVector().y == 0) return;

        // when the player is swinging / attacking, do a micro jump
        if (mc.player.swinging) {
            mc.player.setDeltaMovement(mc.player.getDeltaMovement().x, 0.11, mc.player.getDeltaMovement().z);
            cool = 8;
        }
    }
}
