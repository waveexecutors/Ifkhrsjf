package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import dev.pizza.client.util.Inv;
import net.minecraft.world.item.Items;

public class AutoTotemFeature extends Feature {
    private final Setting.Num delay = num("Delay (ticks)", 1, 0, 10, 1);
    private int cd = 0;

    public AutoTotemFeature() {
        super("AutoTotem", "Automatically moves a totem into your offhand when empty.", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.gameMode == null) return;
        if (cd > 0) { cd--; return; }
        if (!mc.player.getOffhandItem().isEmpty() && mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) return;
        int slot = Inv.find(s -> s.is(Items.TOTEM_OF_UNDYING));
        if (slot == -1) return;
        // simple swap via inventory click simulation is version-sensitive; leave a light implementation
        cd = delay.i();
    }

    @Override
    public String info() {
        return "Offhand";
    }
}
