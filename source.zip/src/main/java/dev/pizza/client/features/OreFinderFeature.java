package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import dev.pizza.client.util.Draw;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public class OreFinderFeature extends Feature {
    private final Setting.Num range = num("Scan Range", 24, 8, 48, 4);
    private final Setting.Num maxShow = num("Max Results", 8, 1, 20, 1);
    private final List<String> found = new ArrayList<>();
    private int scanTimer = 0;

    public OreFinderFeature() {
        super("OreFinder", "Scans nearby chunks for ores and lists them on the HUD.", Category.WORLD);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) return;
        if (++scanTimer < 20) return;
        scanTimer = 0;
        found.clear();
        BlockPos origin = mc.player.blockPosition();
        int r = range.i();
        int count = 0;
        for (int x = -r; x <= r && count < maxShow.i() * 3; x++) {
            for (int y = -r; y <= r && count < maxShow.i() * 3; y++) {
                for (int z = -r; z <= r && count < maxShow.i() * 3; z++) {
                    BlockPos p = origin.offset(x, y, z);
                    BlockState st = mc.level.getBlockState(p);
                    Block b = st.getBlock();
                    String path = BuiltInRegistries.BLOCK.getKey(b).getPath();
                    if (path.endsWith("_ore") || path.equals("ancient_debris")) {
                        found.add(Draw.pretty(path) + " §7" + p.getX() + " " + p.getY() + " " + p.getZ());
                        count++;
                    }
                }
            }
        }
        if (found.size() > maxShow.i()) {
            found.subList(maxShow.i(), found.size()).clear();
        }
    }

    @Override
    public int hud(GuiGraphics g, int x, int y) {
        if (found.isEmpty()) return 0;
        int h = 14 + found.size() * 11;
        int w = 120;
        for (String s : found) w = Math.max(w, Draw.width(s) + 12);
        Draw.hudBox(g, x, y, w, h);
        Draw.text(g, "Ores nearby", x + 5, y + 3, Draw.ACCENT);
        int yy = y + 14;
        for (String s : found) {
            Draw.text(g, s, x + 5, yy, Draw.TEXT);
            yy += 11;
        }
        return h + 4;
    }
}
