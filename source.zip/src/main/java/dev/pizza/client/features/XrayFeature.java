package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Premium Xray – hides non-interesting blocks so ores and structures
 * stand out in true 3D space (faces are never culled).
 */
public class XrayFeature extends Feature {
    public static volatile boolean active = false;
    private static volatile Set<Block> visible = new HashSet<>();
    public static XrayFeature I;

    private final Setting.Bool ores = bool("Ores", true);
    private final Setting.Bool debris = bool("Ancient Debris", true);
    private final Setting.Bool storage = bool("Chests / Storage", true);
    private final Setting.Bool spawners = bool("Spawners / Vaults", true);
    private final Setting.Bool manmade = bool("Base Hints", false);
    public final Setting.Bool fullbright = bool("Linked Fullbright", true);

    public XrayFeature() {
        super("Xray", "3D Xray – hides stone and dirt so ores, chests and structures show through the world.", Category.RENDER);
        I = this;
        for (Setting s : settings) s.onChange = this::refresh;
    }

    @Override
    public void onEnable() {
        rebuild();
        active = true;
        reload();
    }

    @Override
    public void onDisable() {
        active = false;
        reload();
    }

    private void refresh() {
        if (enabled) {
            rebuild();
            reload();
        }
    }

    private void reload() {
        if (mc.level != null && mc.levelRenderer != null) {
            mc.levelRenderer.allChanged();
        }
    }

    private void rebuild() {
        Set<Block> s = new HashSet<>();
        for (Block b : BuiltInRegistries.BLOCK) {
            String p = BuiltInRegistries.BLOCK.getKey(b).getPath();
            if (match(p)) s.add(b);
        }
        visible = s;
    }

    private boolean match(String p) {
        if (ores.value && (p.endsWith("_ore") || p.equals("raw_iron_block") || p.equals("raw_gold_block") || p.equals("raw_copper_block"))) return true;
        if (debris.value && p.equals("ancient_debris")) return true;
        if (storage.value && (p.equals("chest") || p.equals("trapped_chest") || p.equals("ender_chest") || p.equals("barrel")
                || p.endsWith("shulker_box") || p.endsWith("furnace") || p.equals("smoker") || p.equals("hopper")
                || p.equals("crafter") || p.equals("dispenser") || p.equals("dropper") || p.equals("brewing_stand"))) return true;
        if (spawners.value && (p.equals("spawner") || p.equals("trial_spawner") || p.equals("vault"))) return true;
        if (manmade.value && (p.contains("torch") || p.contains("lantern") || p.endsWith("_door") || p.endsWith("planks")
                || p.equals("glass") || p.endsWith("_bed") || p.equals("ladder") || p.endsWith("rail") || p.equals("tnt")
                || p.equals("crafting_table") || p.equals("bookshelf") || p.contains("sign"))) return true;
        return false;
    }

    public static boolean isHidden(BlockState s) {
        return !s.isAir() && !visible.contains(s.getBlock());
    }

    @Override
    public String info() {
        return "3D";
    }
}
