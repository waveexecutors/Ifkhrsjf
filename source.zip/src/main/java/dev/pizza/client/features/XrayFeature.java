package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * 3D Xray – hides non-target blocks completely and disables occlusion so
 * every face of ores/structures is drawn from all angles.
 */
public class XrayFeature extends Feature {
    public static volatile boolean active = false;
    private static volatile Set<Block> visible = new HashSet<>();
    public static XrayFeature I;

    private final Setting.Bool ores = bool("Ores", true);
    private final Setting.Bool debris = bool("Ancient Debris", true);
    private final Setting.Bool diamonds = bool("Diamond Only", false);
    private final Setting.Bool storage = bool("Chests / Storage", true);
    private final Setting.Bool spawners = bool("Spawners / Vaults", true);
    private final Setting.Bool redstone = bool("Redstone", false);
    private final Setting.Bool manmade = bool("Base Hints", false);
    public final Setting.Bool fullbright = bool("Linked Fullbright", true);

    public XrayFeature() {
        super("Xray", "3D Xray with full-face rendering – ores visible from every side.", Category.RENDER);
        I = this;
        for (Setting s : settings) s.onChange = this::refresh;
    }

    @Override
    public void onEnable() {
        rebuild();
        active = true;
        reloadChunks();
    }

    @Override
    public void onDisable() {
        active = false;
        reloadChunks();
    }

    private void refresh() {
        if (!enabled) return;
        rebuild();
        reloadChunks();
    }

    private void reloadChunks() {
        if (mc.level != null && mc.levelRenderer != null) {
            mc.levelRenderer.allChanged();
        }
    }

    private void rebuild() {
        Set<Block> set = new HashSet<>();
        for (Block block : BuiltInRegistries.BLOCK) {
            String path = BuiltInRegistries.BLOCK.getKey(block).getPath();
            if (shouldShow(path)) set.add(block);
        }
        visible = set;
    }

    private boolean shouldShow(String path) {
        if (diamonds.value) {
            return path.equals("diamond_ore") || path.equals("deepslate_diamond_ore")
                    || path.equals("ancient_debris")
                    || (storage.value && isStorage(path))
                    || (spawners.value && isSpawner(path));
        }
        if (ores.value && (path.endsWith("_ore") || (path.startsWith("raw_") && path.endsWith("_block")))) return true;
        if (debris.value && path.equals("ancient_debris")) return true;
        if (storage.value && isStorage(path)) return true;
        if (spawners.value && isSpawner(path)) return true;
        if (redstone.value && (path.contains("redstone") || path.equals("repeater") || path.equals("comparator")
                || path.equals("observer") || path.equals("piston") || path.equals("sticky_piston"))) return true;
        if (manmade.value && (path.contains("torch") || path.contains("lantern") || path.endsWith("_door")
                || path.endsWith("planks") || path.contains("glass") || path.endsWith("_bed")
                || path.equals("ladder") || path.contains("rail") || path.equals("crafting_table")
                || path.equals("bookshelf") || path.contains("sign") || path.equals("tnt"))) return true;
        return false;
    }

    private static boolean isStorage(String p) {
        return p.equals("chest") || p.equals("trapped_chest") || p.equals("ender_chest") || p.equals("barrel")
                || p.endsWith("shulker_box") || p.endsWith("furnace") || p.equals("smoker") || p.equals("blast_furnace")
                || p.equals("hopper") || p.equals("crafter") || p.equals("dispenser") || p.equals("dropper")
                || p.equals("brewing_stand");
    }

    private static boolean isSpawner(String p) {
        return p.equals("spawner") || p.equals("trial_spawner") || p.equals("vault");
    }

    public static boolean isHidden(BlockState state) {
        return active && !state.isAir() && !visible.contains(state.getBlock());
    }

    @Override
    public String info() {
        return diamonds.value ? "Diamonds" : "Full";
    }
}
