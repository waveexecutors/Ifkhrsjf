package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import dev.pizza.client.util.Chat;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.world.entity.player.Player;

public class PlayerAlertFeature extends Feature {
    private final Setting.Num range = num("Alert Range", 48, 16, 128, 8);
    private final Set<String> seen = new HashSet<>();

    public PlayerAlertFeature() {
        super("PlayerAlert", "Chat notification when a new player enters your range.", Category.PLAYER);
    }

    @Override
    public void onEnable() {
        seen.clear();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) return;
        Set<String> current = new HashSet<>();
        for (Player p : mc.level.players()) {
            if (p == mc.player) continue;
            if (p.distanceTo(mc.player) > range.value) continue;
            String name = p.getName().getString();
            current.add(name);
            if (!seen.contains(name)) {
                Chat.info("Player nearby: §e" + name + " §7(" + String.format("%.0f", p.distanceTo(mc.player)) + "m)");
            }
        }
        seen.clear();
        seen.addAll(current);
    }
}
