package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import dev.pizza.client.util.Chat;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;

/**
 * Client-side survival helpers for food and health.
 *
 * IMPORTANT: On a normal vanilla dedicated server, health and hunger are
 * controlled by the server. Client-only changes are overwritten every tick.
 * This module keeps food topped up via Auto-Eat style logic and re-applies
 * regeneration / saturation effects when possible. It does not grant true
 * invulnerability on multiplayer unless the server trusts the client
 * (e.g. singleplayer, or a server with broken/absent validation).
 */
public class SurvivalLockFeature extends Feature {
    private final Setting.Bool lockHunger = bool("Keep Hunger Full", true);
    private final Setting.Bool lockSaturation = bool("Keep Saturation", true);
    private final Setting.Bool regenEffect = bool("Regen Effect", true);
    private final Setting.Bool resistEffect = bool("Resistance Effect", false);
    private final Setting.Bool autoGapple = bool("Emergency Gapple", true);
    private final Setting.Num gappleHealth = num("Gapple Below HP", 10, 4, 18, 1);

    private int tick;

    public SurvivalLockFeature() {
        super("SurvivalLock", "Keeps hunger/saturation topped up and applies soft regen. Limited on real multiplayer servers.", Category.PLAYER);
    }

    @Override
    public void onEnable() {
        Chat.info("SurvivalLock on – works best in singleplayer; multiplayer servers control health/hunger.");
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) return;
        Player p = mc.player;
        tick++;

        if (lockHunger.value && p.getFoodData().getFoodLevel() < 20) {
            p.getFoodData().setFoodLevel(20);
        }
        if (lockSaturation.value) {
            p.getFoodData().setSaturation(20f);
        }

        if (regenEffect.value && (tick % 40 == 0)) {
            p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 80, 1, false, false, false));
            p.addEffect(new MobEffectInstance(MobEffects.SATURATION, 40, 0, false, false, false));
        }
        if (resistEffect.value && (tick % 40 == 0)) {
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 80, 0, false, false, false));
        }

        if (autoGapple.value && p.getHealth() > 0 && p.getHealth() <= gappleHealth.value && !p.isUsingItem()) {
            // try use gapple from hotbar
            for (int i = 0; i < 9; i++) {
                var stack = p.getInventory().getItem(i);
                if (stack.is(net.minecraft.world.item.Items.GOLDEN_APPLE)
                        || stack.is(net.minecraft.world.item.Items.ENCHANTED_GOLDEN_APPLE)) {
                    int prev = p.getInventory().getSelectedSlot();
                    p.getInventory().setSelectedSlot(i);
                    if (mc.gameMode != null) {
                        mc.gameMode.useItem(p, net.minecraft.world.InteractionHand.MAIN_HAND);
                    }
                    p.getInventory().setSelectedSlot(prev);
                    break;
                }
            }
        }
    }

    @Override
    public String info() {
        return lockHunger.value ? "Food+" : "On";
    }
}
