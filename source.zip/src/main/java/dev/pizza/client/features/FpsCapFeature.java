package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import dev.pizza.client.util.Chat;

/**
 * Configurable FPS Capper. Overrides the vanilla framerate limit while enabled.
 */
public class FpsCapFeature extends Feature {
    public static FpsCapFeature I;

    private final Setting.Num cap = num("FPS Cap", 144, 30, 1000, 5);
    private final Setting.Bool unlimited = bool("Unlimited (VSync off)", false);

    private int previousLimit = 120;
    private boolean previousVsync = true;

    public FpsCapFeature() {
        super("FPS Cap", "Configurable framerate limiter. Useful for consistent timing and lower GPU heat.", Category.MISC);
        I = this;
        cap.onChange = this::apply;
        unlimited.onChange = this::apply;
    }

    @Override
    public void onEnable() {
        if (mc.options != null) {
            previousLimit = mc.options.framerateLimit().get();
            previousVsync = mc.options.enableVsync().get();
        }
        apply();
        Chat.info("FPS Cap set to " + (unlimited.value ? "Unlimited" : cap.i()));
    }

    @Override
    public void onDisable() {
        if (mc.options != null) {
            mc.options.framerateLimit().set(previousLimit);
            mc.options.enableVsync().set(previousVsync);
        }
    }

    private void apply() {
        if (!enabled || mc.options == null) return;
        if (unlimited.value) {
            mc.options.framerateLimit().set(260); // vanilla "unlimited" style
            mc.options.enableVsync().set(false);
        } else {
            mc.options.framerateLimit().set(cap.i());
        }
    }

    @Override
    public void onTick() {
        // re-apply in case something else changed the option
        if (enabled) apply();
    }

    @Override
    public String info() {
        return unlimited.value ? "∞" : String.valueOf(cap.i());
    }
}
