package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Simple KillAura – targets nearest valid entity in range and attacks on cooldown.
 * Rotation is smoothed. Keep range and CPS moderate on multiplayer.
 */
public class KillAuraFeature extends Feature {
    private final Setting.Num range = num("Range", 3.2, 2.5, 4.5, 0.1);
    private final Setting.Num cps = num("CPS", 9, 4, 14, 1);
    private final Setting.Bool players = bool("Players", true);
    private final Setting.Bool monsters = bool("Monsters", true);
    private final Setting.Bool animals = bool("Animals / Others", false);
    private final Setting.Bool throughWalls = bool("Through Walls", false);
    private final Setting.Num rotateSpeed = num("Rotate Speed", 40, 10, 180, 5);
    private final Setting.Bool swing = bool("Swing Arm", true);

    private long lastAttack = 0;
    private Entity current;

    public KillAuraFeature() {
        super("KillAura", "Attacks nearby targets automatically with smoothed rotation.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;
        if (mc.screen != null) return;

        current = findTarget();
        if (current == null) return;

        // smooth look toward target
        lookAt(current.position().add(0, current.getBbHeight() * 0.6, 0), rotateSpeed.value);

        long now = System.currentTimeMillis();
        long interval = (long) (1000.0 / cps.value);
        if (now - lastAttack < interval) return;
        if (!mc.player.getAbilities().instabuild) {
            // respect vanilla attack cooldown roughly
            if (mc.player.getAttackStrengthScale(0.5f) < 0.85f) return;
        }

        lastAttack = now;
        mc.gameMode.attack(mc.player, current);
        if (swing.value) mc.player.swing(InteractionHand.MAIN_HAND);
    }

    private Entity findTarget() {
        Entity best = null;
        double bestDist = range.value;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity living) || !living.isAlive()) continue;
            if (e == mc.player) continue;
            if (e instanceof Player && !players.value) continue;
            if (e instanceof Monster && !monsters.value) continue;
            if (!(e instanceof Player) && !(e instanceof Monster) && !animals.value) continue;
            double d = mc.player.distanceTo(e);
            if (d > bestDist) continue;
            if (!throughWalls.value && !mc.player.hasLineOfSight(e)) continue;
            bestDist = d;
            best = e;
        }
        return best;
    }

    private void lookAt(Vec3 point, double speedDeg) {
        Vec3 eyes = mc.player.getEyePosition();
        double dx = point.x - eyes.x;
        double dy = point.y - eyes.y;
        double dz = point.z - eyes.z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float targetYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, dist));

        float yaw = mc.player.getYRot();
        float pitch = mc.player.getXRot();
        float dyaw = wrap(targetYaw - yaw);
        float dpitch = targetPitch - pitch;
        float max = (float) speedDeg;
        dyaw = clamp(dyaw, -max, max);
        dpitch = clamp(dpitch, -max, max);
        mc.player.setYRot(yaw + dyaw);
        mc.player.setXRot(clamp(pitch + dpitch, -90, 90));
    }

    private static float wrap(float a) {
        while (a > 180) a -= 360;
        while (a < -180) a += 360;
        return a;
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    @Override
    public String info() {
        return current == null ? null : String.format("%.1fm", range.value);
    }
}
