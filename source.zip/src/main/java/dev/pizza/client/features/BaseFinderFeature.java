package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import dev.pizza.client.util.Draw;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Finds base-related blocks and draws large pizza-gradient markers so they
 * are obvious from a distance.
 */
public class BaseFinderFeature extends Feature {
    public static BaseFinderFeature I;

    private final Setting.Num range = num("Scan Range", 48, 16, 96, 4);
    private final Setting.Num maxBlocks = num("Max Markers", 64, 8, 150, 4);
    private final Setting.Bool chests = bool("Chests / Storage", true);
    private final Setting.Bool spawners = bool("Spawners / Vaults", true);
    private final Setting.Bool utility = bool("Beacon / Enchant / Anvil", true);
    private final Setting.Bool portals = bool("Portals / Frames", true);
    private final Setting.Num markerSize = num("Marker Size", 1.2, 0.6, 2.5, 0.1);

    private final List<Hit> hits = new ArrayList<>();
    private int timer = 0;

    private static final class Hit {
        final BlockPos pos;
        final String label;
        Hit(BlockPos pos, String label) {
            this.pos = pos;
            this.label = label;
        }
    }

    public BaseFinderFeature() {
        super("BaseFinder", "Highlights base blocks with bright pizza-colored markers and labels.", Category.WORLD);
        I = this;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) return;
        if (++timer < 15) return;
        timer = 0;
        hits.clear();
        BlockPos origin = mc.player.blockPosition();
        int r = range.i();
        int limit = maxBlocks.i();

        // denser scan near player, coarser farther out would be ideal; keep uniform for simplicity
        for (int x = -r; x <= r && hits.size() < limit; x++) {
            for (int y = -Math.min(r, 32); y <= Math.min(r, 48) && hits.size() < limit; y++) {
                for (int z = -r; z <= r && hits.size() < limit; z++) {
                    BlockPos p = origin.offset(x, y, z);
                    BlockState st = mc.level.getBlockState(p);
                    if (st.isAir()) continue;
                    String path = BuiltInRegistries.BLOCK.getKey(st.getBlock()).getPath();
                    String label = labelOf(path);
                    if (label != null) hits.add(new Hit(p.immutable(), label));
                }
            }
        }
    }

    private String labelOf(String path) {
        if (chests.value) {
            if (path.equals("chest") || path.equals("trapped_chest")) return "Chest";
            if (path.equals("ender_chest")) return "Ender";
            if (path.equals("barrel")) return "Barrel";
            if (path.contains("shulker")) return "Shulker";
            if (path.equals("hopper")) return "Hopper";
        }
        if (spawners.value) {
            if (path.equals("spawner")) return "Spawner";
            if (path.equals("trial_spawner")) return "Trial";
            if (path.equals("vault")) return "Vault";
        }
        if (utility.value) {
            if (path.equals("beacon")) return "Beacon";
            if (path.equals("enchanting_table")) return "Enchant";
            if (path.contains("anvil")) return "Anvil";
            if (path.equals("crafting_table")) return "Craft";
            if (path.equals("brewing_stand")) return "Brew";
        }
        if (portals.value) {
            if (path.equals("nether_portal") || path.equals("end_portal") || path.equals("end_portal_frame")
                    || path.equals("end_gateway")) return "Portal";
        }
        return null;
    }

    public void renderHighlights(GuiGraphics g) {
        if (!enabled || mc.player == null || mc.level == null || mc.gameRenderer == null) return;
        if (hits.isEmpty()) return;

        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        Vec3 cam = mc.gameRenderer.getMainCamera().position();
        float yaw = mc.gameRenderer.getMainCamera().yRot();
        float pitch = mc.gameRenderer.getMainCamera().xRot();
        double cosYaw = Math.cos(Math.toRadians(-yaw));
        double sinYaw = Math.sin(Math.toRadians(-yaw));
        double cosPitch = Math.cos(Math.toRadians(-pitch));
        double sinPitch = Math.sin(Math.toRadians(-pitch));

        int i = 0;
        for (Hit hit : hits) {
            Vec3 center = Vec3.atCenterOf(hit.pos);
            double dx = center.x - cam.x;
            double dy = center.y - cam.y;
            double dz = center.z - cam.z;
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

            double x1 = dx * cosYaw + dz * sinYaw;
            double z1 = -dx * sinYaw + dz * cosYaw;
            double y1 = dy * cosPitch - z1 * sinPitch;
            double z2 = dy * sinPitch + z1 * cosPitch;
            if (z2 < 0.2) { i++; continue; }

            double scale = (sw / 2.0) / (Math.tan(Math.toRadians(70) / 2.0) * z2);
            int sx = (int) (sw / 2.0 + x1 * scale);
            int sy = (int) (sh / 2.0 - y1 * scale);
            int size = (int) Math.max(8, Math.min(40, 22.0 * scale / 18.0 * markerSize.value));

            float t = (i % 16) / 16f;
            int color = pizzaGradient(t);
            int fill = (color & 0x00FFFFFF) | 0x66000000;

            int left = sx - size / 2;
            int top = sy - size / 2;
            int right = left + size;
            int bottom = top + size;

            // filled box + thick border
            g.fill(left, top, right, bottom, fill);
            g.fill(left - 1, top - 1, right + 1, top, color);
            g.fill(left - 1, bottom, right + 1, bottom + 1, color);
            g.fill(left - 1, top, left, bottom, color);
            g.fill(right, top, right + 1, bottom, color);

            // corner ticks
            int c = Math.max(3, size / 4);
            g.fill(left, top, left + c, top + 2, 0xFFFFFFFF);
            g.fill(left, top, left + 2, top + c, 0xFFFFFFFF);
            g.fill(right - c, top, right, top + 2, 0xFFFFFFFF);
            g.fill(right - 2, top, right, top + c, 0xFFFFFFFF);

            String tag = hit.label + " §7" + String.format("%.0fm", dist);
            int tw = Draw.width(tag);
            Draw.text(g, tag, sx - tw / 2, top - 12, color);
            i++;
        }
    }

    private static int pizzaGradient(float t) {
        int r, g, b;
        if (t < 0.5f) {
            float u = t * 2f;
            r = 255;
            g = (int) (90 + (190 - 90) * u);
            b = (int) (40 + (40 - 40) * u);
        } else {
            float u = (t - 0.5f) * 2f;
            r = (int) (255 - 30 * u);
            g = (int) (190 - 140 * u);
            b = (int) (40 + 30 * u);
        }
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    @Override
    public int hud(GuiGraphics g, int x, int y) {
        if (hits.isEmpty()) return 0;
        String l = "BaseFinder  " + hits.size();
        int w = Draw.width(l) + 10;
        Draw.hudBox(g, x, y, w, 14);
        Draw.text(g, l, x + 5, y + 3, Draw.ACCENT);
        return 18;
    }

    @Override
    public String info() {
        return hits.isEmpty() ? null : String.valueOf(hits.size());
    }
}
