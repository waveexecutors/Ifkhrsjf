package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import dev.pizza.client.util.Draw;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Scans for player-made structures and draws pizza-colored gradient boxes
 * on the interesting blocks so bases light up visually.
 */
public class BaseFinderFeature extends Feature {
    public static BaseFinderFeature I;

    private final Setting.Num range = num("Scan Range", 40, 16, 80, 4);
    private final Setting.Num maxBlocks = num("Max Highlights", 48, 8, 120, 4);
    private final Setting.Bool chests = bool("Chests / Storage", true);
    private final Setting.Bool spawners = bool("Spawners / Vaults", true);
    private final Setting.Bool beacons = bool("Beacons / Enchant", true);

    private final List<BlockPos> hits = new ArrayList<>();
    private int timer = 0;

    public BaseFinderFeature() {
        super("BaseFinder", "Highlights base blocks with a pizza-colored gradient so structures stand out.", Category.WORLD);
        I = this;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) return;
        if (++timer < 25) return;
        timer = 0;
        hits.clear();
        BlockPos origin = mc.player.blockPosition();
        int r = range.i();
        int limit = maxBlocks.i();

        for (int x = -r; x <= r && hits.size() < limit; x += 1) {
            for (int y = -r / 2; y <= r / 2 && hits.size() < limit; y += 1) {
                for (int z = -r; z <= r && hits.size() < limit; z += 1) {
                    BlockPos p = origin.offset(x, y, z);
                    BlockState st = mc.level.getBlockState(p);
                    String path = BuiltInRegistries.BLOCK.getKey(st.getBlock()).getPath();
                    if (match(path)) hits.add(p.immutable());
                }
            }
        }
    }

    private boolean match(String path) {
        if (chests.value && (path.equals("chest") || path.equals("trapped_chest") || path.equals("ender_chest")
                || path.equals("barrel") || path.contains("shulker") || path.equals("hopper"))) return true;
        if (spawners.value && (path.equals("spawner") || path.equals("trial_spawner") || path.equals("vault"))) return true;
        if (beacons.value && (path.equals("beacon") || path.equals("enchanting_table") || path.equals("anvil")
                || path.equals("chipped_anvil") || path.equals("damaged_anvil"))) return true;
        return false;
    }

    /** Draw pizza-gradient boxes on found blocks (screen-space). */
    public void renderHighlights(GuiGraphics g) {
        if (!enabled || mc.player == null || mc.level == null || mc.gameRenderer == null) return;
        if (hits.isEmpty()) return;

        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        Vec3 cam = mc.gameRenderer.getMainCamera().position();
        float yaw = mc.gameRenderer.getMainCamera().yRot();
        float pitch = mc.gameRenderer.getMainCamera().xRot();
        double cosYaw = Math.cos(Math.toRadians(-yaw));
        double sinYaw = Math.sin(Math.toRadians(-yaw));
        double cosPitch = Math.cos(Math.toRadians(-pitch));
        double sinPitch = Math.sin(Math.toRadians(-pitch));

        int i = 0;
        for (BlockPos p : hits) {
            Vec3 center = Vec3.atCenterOf(p);
            double dx = center.x - cam.x;
            double dy = center.y - cam.y;
            double dz = center.z - cam.z;

            double x1 = dx * cosYaw + dz * sinYaw;
            double z1 = -dx * sinYaw + dz * cosYaw;
            double y1 = dy * cosPitch - z1 * sinPitch;
            double z2 = dy * sinPitch + z1 * cosPitch;
            if (z2 < 0.15) { i++; continue; }

            double scale = (sw / 2.0) / (Math.tan(Math.toRadians(70) / 2.0) * z2);
            int sx = (int) (sw / 2.0 + x1 * scale);
            int sy = (int) (sh / 2.0 - y1 * scale);
            int size = (int) Math.max(6, Math.min(28, 18.0 * scale / 20.0));

            // pizza gradient: orange -> yellow -> red based on index
            float t = (i % 12) / 12f;
            int color = pizzaGradient(t);
            int fill = (color & 0x00FFFFFF) | 0x55000000;

            int left = sx - size / 2;
            int top = sy - size / 2;
            g.fill(left, top, left + size, top + size, fill);
            // bright border
            g.fill(left, top, left + size, top + 1, color);
            g.fill(left, top + size - 1, left + size, top + size, color);
            g.fill(left, top, left + 1, top + size, color);
            g.fill(left + size - 1, top, left + size, top + size, color);
            i++;
        }
    }

    /** Orange → gold → tomato pizza palette. */
    private static int pizzaGradient(float t) {
        // 0 = deep orange, 0.5 = cheese gold, 1 = tomato red
        int r, g, b;
        if (t < 0.5f) {
            float u = t * 2f;
            r = 255;
            g = (int) (107 + (200 - 107) * u);
            b = (int) (53 + (50 - 53) * u);
        } else {
            float u = (t - 0.5f) * 2f;
            r = (int) (255 - 40 * u);
            g = (int) (200 - 150 * u);
            b = (int) (50 + 20 * u);
        }
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    @Override
    public int hud(GuiGraphics g, int x, int y) {
        if (hits.isEmpty()) return 0;
        String l = "Base  " + hits.size() + " signals";
        int w = Draw.width(l) + 10;
        Draw.hudBox(g, x, y, w, 14);
        Draw.text(g, l, x + 5, y + 3, Draw.ACCENT);
        return 18;
    }

    @Override
    public String info() {
        return hits.isEmpty() ? null : hits.size() + "";
    }
}
