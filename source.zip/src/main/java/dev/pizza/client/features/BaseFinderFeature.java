package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import dev.pizza.client.util.Draw;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.state.BlockState;

public class BaseFinderFeature extends Feature {
    private final Setting.Num range = num("Scan Range", 32, 12, 64, 4);
    private final List<String> hits = new ArrayList<>();
    private int timer = 0;

    public BaseFinderFeature() {
        super("BaseFinder", "Detects player-made structures (chests, spawners, doors, etc.).", Category.WORLD);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) return;
        if (++timer < 40) return;
        timer = 0;
        hits.clear();
        BlockPos o = mc.player.blockPosition();
        int r = range.i();
        for (int x = -r; x <= r; x += 2) {
            for (int y = -r / 2; y <= r / 2; y += 2) {
                for (int z = -r; z <= r; z += 2) {
                    BlockPos p = o.offset(x, y, z);
                    BlockState st = mc.level.getBlockState(p);
                    String path = BuiltInRegistries.BLOCK.getKey(st.getBlock()).getPath();
                    if (path.equals("chest") || path.equals("ender_chest") || path.equals("spawner")
                            || path.equals("trial_spawner") || path.equals("barrel") || path.contains("shulker")
                            || path.equals("beacon") || path.equals("enchanting_table")) {
                        hits.add(Draw.pretty(path) + " §7" + p.getX() + " " + p.getY() + " " + p.getZ());
                        if (hits.size() >= 6) return;
                    }
                }
            }
        }
    }

    @Override
    public int hud(GuiGraphics g, int x, int y) {
        if (hits.isEmpty()) return 0;
        int h = 14 + hits.size() * 11;
        int w = 130;
        for (String s : hits) w = Math.max(w, Draw.width(s) + 12);
        Draw.hudBox(g, x, y, w, h);
        Draw.text(g, "Base signals", x + 5, y + 3, Draw.ACCENT);
        int yy = y + 14;
        for (String s : hits) {
            Draw.text(g, s, x + 5, yy, Draw.TEXT);
            yy += 11;
        }
        return h + 4;
    }
}
