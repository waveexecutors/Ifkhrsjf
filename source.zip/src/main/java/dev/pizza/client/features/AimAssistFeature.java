package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Soft aim assist – gently pulls crosshair toward the nearest target while
 * attacking or aiming. Strength is intentionally limited so it feels natural.
 */
public class AimAssistFeature extends Feature {
    private final Setting.Num range = num("Range", 4.5, 2.5, 6.0, 0.1);
    private final Setting.Num strength = num("Strength", 12, 2, 40, 1);
    private final Setting.Bool onAttack = bool("Only While Attacking", true);
    private final Setting.Bool players = bool("Players", true);
    private final Setting.Bool monsters = bool("Monsters", true);
    private final Setting.Num fov = num("FOV Limit", 60, 20, 180, 5);

    public AimAssistFeature() {
        super("AimAssist", "Soft aim pull toward nearby targets. Low strength looks more natural.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) return;
        if (mc.screen != null) return;
        if (onAttack.value && (mc.options == null || !mc.options.keyAttack.isDown())) return;

        Entity target = findTarget();
        if (target == null) return;

        Vec3 point = target.position().add(0, target.getBbHeight() * 0.55, 0);
        Vec3 eyes = mc.player.getEyePosition();
        double dx = point.x - eyes.x;
        double dy = point.y - eyes.y;
        double dz = point.z - eyes.z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float targetYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, dist));

        float yaw = mc.player.getYRot();
        float pitch = mc.player.getXRot();
        float dyaw = wrap(targetYaw - yaw);
        float dpitch = targetPitch - pitch;

        if (Math.abs(dyaw) > fov.value && Math.abs(dpitch) > fov.value) return;

        float step = (float) strength.value * 0.15f;
        dyaw = clamp(dyaw, -step, step);
        dpitch = clamp(dpitch, -step, step);
        mc.player.setYRot(yaw + dyaw);
        mc.player.setXRot(clamp(pitch + dpitch, -90, 90));
    }

    private Entity findTarget() {
        Entity best = null;
        double bestDist = range.value;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity living) || !living.isAlive()) continue;
            if (e == mc.player) continue;
            if (e instanceof Player && !players.value) continue;
            if (e instanceof Monster && !monsters.value) continue;
            if (!(e instanceof Player) && !(e instanceof Monster)) continue;
            double d = mc.player.distanceTo(e);
            if (d > bestDist) continue;
            if (!mc.player.hasLineOfSight(e)) continue;
            bestDist = d;
            best = e;
        }
        return best;
    }

    private static float wrap(float a) {
        while (a > 180) a -= 360;
        while (a < -180) a += 360;
        return a;
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    @Override
    public String info() {
        return strength.i() + "";
    }
}
