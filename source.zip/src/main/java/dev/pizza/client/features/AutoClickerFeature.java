package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Clicks at a configurable CPS while the attack key is held.
 * Keep CPS moderate.
 */
public class AutoClickerFeature extends Feature {
    private final Setting.Num cps = num("CPS", 10, 1, 16, 1);
    private final Setting.Bool onlyEntities = bool("Only On Entities", true);
    private final Setting.Bool weaponOnly = bool("Weapons Only", false);

    private long lastClick = 0;

    public AutoClickerFeature() {
        super("AutoClicker", "Attacks at a steady CPS while holding the attack button.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.gameMode == null || mc.options == null) return;
        if (!mc.options.keyAttack.isDown()) return;
        if (mc.screen != null) return;

        if (weaponOnly.value) {
            var s = mc.player.getMainHandItem();
            String p = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(s.getItem()).getPath();
            if (!(p.contains("sword") || p.contains("axe") || p.contains("trident"))) return;
        }

        if (onlyEntities.value) {
            HitResult hr = mc.hitResult;
            if (!(hr instanceof EntityHitResult)) return;
        }

        long now = System.currentTimeMillis();
        long interval = (long) (1000.0 / cps.value);
        if (now - lastClick < interval) return;
        lastClick = now;

        // trigger the normal attack path
        mc.options.keyAttack.setDown(true);
        mc.player.swing(InteractionHand.MAIN_HAND);
        if (mc.hitResult instanceof EntityHitResult er && er.getEntity() != null) {
            mc.gameMode.attack(mc.player, er.getEntity());
        }
    }

    @Override
    public String info() {
        return cps.i() + " CPS";
    }
}
