package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;

public class StepFeature extends Feature {
    private final Setting.Num height = num("Height", 1.0, 0.6, 2.5, 0.1);
    private double previous = 0.6;

    public StepFeature() {
        super("Step", "Walk up blocks without jumping. Uses the step_height attribute.", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        AttributeInstance attr = getAttr();
        if (attr != null) previous = attr.getBaseValue();
        apply();
    }

    @Override
    public void onDisable() {
        AttributeInstance attr = getAttr();
        if (attr != null) attr.setBaseValue(previous);
    }

    @Override
    public void onTick() {
        apply();
    }

    private void apply() {
        AttributeInstance attr = getAttr();
        if (attr != null) attr.setBaseValue(height.value);
    }

    private AttributeInstance getAttr() {
        if (mc.player == null) return null;
        return mc.player.getAttribute(Attributes.STEP_HEIGHT);
    }

    @Override
    public String info() {
        return height.text();
    }
}
