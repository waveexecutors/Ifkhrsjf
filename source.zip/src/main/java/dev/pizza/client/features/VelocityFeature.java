package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import net.minecraft.world.phys.Vec3;

/**
 * Reduces knockback. Horizontal / vertical percentages are configurable.
 * Client-side only – keep values moderate.
 */
public class VelocityFeature extends Feature {
    private final Setting.Num horizontal = num("Horizontal %", 0, 0, 100, 5);
    private final Setting.Num vertical = num("Vertical %", 0, 0, 100, 5);

    private Vec3 lastMotion = Vec3.ZERO;

    public VelocityFeature() {
        super("Velocity", "Reduces knockback taken from hits and explosions.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        Vec3 v = mc.player.getDeltaMovement();
        // when velocity spikes upward/sideways suddenly (knockback), scale it
        if (mc.player.hurtTime > 0 && mc.player.hurtTime < 8) {
            double hx = lastMotion.x + (v.x - lastMotion.x) * (horizontal.value / 100.0);
            double hy = lastMotion.y + (v.y - lastMotion.y) * (vertical.value / 100.0);
            double hz = lastMotion.z + (v.z - lastMotion.z) * (horizontal.value / 100.0);
            // if percentages are low we pull toward zero more aggressively
            if (horizontal.value < 50) {
                hx = v.x * (horizontal.value / 100.0);
                hz = v.z * (horizontal.value / 100.0);
            }
            if (vertical.value < 50) {
                hy = v.y * (vertical.value / 100.0);
            }
            mc.player.setDeltaMovement(hx, hy, hz);
        }
        lastMotion = mc.player.getDeltaMovement();
    }

    @Override
    public String info() {
        return horizontal.i() + "/" + vertical.i();
    }
}
