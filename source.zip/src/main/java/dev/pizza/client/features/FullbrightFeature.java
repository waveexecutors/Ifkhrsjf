package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;

public class FullbrightFeature extends Feature {
    public static FullbrightFeature I;
    private final Setting.Num gamma = num("Gamma", 16.0, 1.0, 16.0, 0.5);
    private double previous = 1.0;

    public FullbrightFeature() {
        super("Fullbright", "Maximum brightness. Works great together with Xray.", Category.RENDER);
        I = this;
    }

    public static void update() {
        if (I == null || MinecraftHolder.mc().options == null) return;
        if (I.enabled || (XrayFeature.I != null && XrayFeature.I.enabled && XrayFeature.I.fullbright.value)) {
            MinecraftHolder.mc().options.gamma().set(I.gamma.value);
        }
    }

    @Override
    public void onEnable() {
        if (mc.options != null) previous = mc.options.gamma().get();
        update();
    }

    @Override
    public void onDisable() {
        if (mc.options != null) mc.options.gamma().set(previous);
    }

    @Override
    public void onTick() {
        update();
    }

    // tiny helper to avoid static Minecraft import issues in some mappings
    private static final class MinecraftHolder {
        static net.minecraft.client.Minecraft mc() {
            return net.minecraft.client.Minecraft.getInstance();
        }
    }
}
