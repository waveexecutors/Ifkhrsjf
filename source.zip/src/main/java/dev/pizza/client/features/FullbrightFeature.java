package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/**
 * Reliable Fullbright for 1.21.x.
 * Forces gamma every tick and optionally applies a silent Night Vision effect
 * so caves stay fully lit even when the gamma slider is clamped by the game.
 */
public class FullbrightFeature extends Feature {
    public static FullbrightFeature I;

    private final Setting.Num gamma = num("Gamma", 16.0, 1.0, 100.0, 1.0);
    private final Setting.Bool nightVision = bool("Night Vision Backup", true);

    private double previousGamma = 1.0;
    private boolean hadNv = false;

    public FullbrightFeature() {
        super("Fullbright", "Full brightness in caves and with Xray. Gamma + optional Night Vision.", Category.RENDER);
        I = this;
    }

    public static void update() {
        if (I == null) return;
        I.apply();
    }

    private void apply() {
        if (mc.options == null) return;
        boolean want = enabled || (XrayFeature.I != null && XrayFeature.I.enabled && XrayFeature.I.fullbright.value);
        if (want) {
            mc.options.gamma().set(Math.max(gamma.value, 16.0));
            if (nightVision.value && mc.player != null) {
                MobEffectInstance existing = mc.player.getEffect(MobEffects.NIGHT_VISION);
                if (existing == null || existing.getDuration() < 220) {
                    mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, false));
                    hadNv = true;
                }
            }
        }
    }

    @Override
    public void onEnable() {
        if (mc.options != null) previousGamma = mc.options.gamma().get();
        apply();
    }

    @Override
    public void onDisable() {
        if (mc.options != null) mc.options.gamma().set(previousGamma);
        if (hadNv && mc.player != null) {
            mc.player.removeEffect(MobEffects.NIGHT_VISION);
            hadNv = false;
        }
    }

    @Override
    public void onTick() {
        apply();
    }

    @Override
    public String info() {
        return nightVision.value ? "NV+" : String.valueOf(gamma.i());
    }
}
