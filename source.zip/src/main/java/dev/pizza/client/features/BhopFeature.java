package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import net.minecraft.world.phys.Vec3;

/**
 * Configurable Bhop with optional full strafe mode.
 * Strafe mode lets you change direction mid-air freely (instant side movement).
 */
public class BhopFeature extends Feature {
    public static BhopFeature I;

    private final Setting.Num speed = num("Speed Multiplier", 1.45, 1.0, 3.5, 0.05);
    private final Setting.Num jumpHeight = num("Jump Height", 0.42, 0.28, 0.8, 0.01);
    private final Setting.Bool autoSprint = bool("Auto Sprint", true);
    private final Setting.Bool onlyWhenMoving = bool("Only When Moving", true);
    private final Setting.Bool lowhop = bool("Lowhop", false);
    private final Setting.Bool strafe = bool("Strafe Bhop", true);
    private final Setting.Num strafeStrength = num("Strafe Strength", 1.0, 0.3, 2.0, 0.05);
    private final Setting.Num groundBoost = num("Ground Boost", 0.22, 0.05, 0.6, 0.01);

    private int groundTicks = 0;

    public BhopFeature() {
        super("Bhop", "Bunny hop with strafe mode – move instantly in any direction while airborne.", Category.MOVEMENT);
        I = this;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) return;
        if (mc.player.getAbilities().flying || mc.player.isPassenger() || mc.player.isInWater() || mc.player.isInLava()) return;

        float forward = mc.player.input.getMoveVector().y;
        float strafeIn = mc.player.input.getMoveVector().x;
        boolean moving = forward != 0 || strafeIn != 0;
        if (onlyWhenMoving.value && !moving) return;

        if (autoSprint.value && moving && !mc.player.isSprinting()) {
            mc.player.setSprinting(true);
        }

        if (mc.player.onGround()) {
            groundTicks++;
            if (groundTicks >= 1) {
                double jh = lowhop.value ? 0.32 : jumpHeight.value;
                Vec3 v = mc.player.getDeltaMovement();
                mc.player.setDeltaMovement(v.x, jh, v.z);
                mc.player.jumpFromGround();

                // directional ground boost based on input
                float yaw = mc.player.getYRot() * 0.017453292f;
                double mx = 0, mz = 0;
                if (forward != 0 || strafeIn != 0) {
                    // normalize input
                    float len = (float) Math.sqrt(forward * forward + strafeIn * strafeIn);
                    if (len > 0.01f) {
                        forward /= len;
                        strafeIn /= len;
                    }
                    mx = (forward * -Math.sin(yaw) + strafeIn * Math.cos(yaw)) * groundBoost.value * speed.value;
                    mz = (forward * Math.cos(yaw) + strafeIn * Math.sin(yaw)) * groundBoost.value * speed.value;
                } else {
                    mx = -Math.sin(yaw) * groundBoost.value * speed.value;
                    mz = Math.cos(yaw) * groundBoost.value * speed.value;
                }
                mc.player.setDeltaMovement(
                        mc.player.getDeltaMovement().x + mx,
                        mc.player.getDeltaMovement().y,
                        mc.player.getDeltaMovement().z + mz
                );
                groundTicks = 0;
            }
        } else {
            groundTicks = 0;
            if (!moving) return;

            if (strafe.value) {
                // Full air strafe – velocity follows look + input immediately
                float yaw = mc.player.getYRot() * 0.017453292f;
                float len = (float) Math.sqrt(forward * forward + strafeIn * strafeIn);
                if (len > 0.01f) {
                    forward /= len;
                    strafeIn /= len;
                }
                double targetSpeed = 0.26 * speed.value * strafeStrength.value;
                double nx = (forward * -Math.sin(yaw) + strafeIn * Math.cos(yaw)) * targetSpeed;
                double nz = (forward * Math.cos(yaw) + strafeIn * Math.sin(yaw)) * targetSpeed;

                Vec3 v = mc.player.getDeltaMovement();
                // blend toward desired direction so it feels responsive but not teleporty
                double blend = 0.55 * strafeStrength.value;
                blend = Math.min(0.95, blend);
                mc.player.setDeltaMovement(
                        v.x * (1.0 - blend) + nx * blend,
                        v.y,
                        v.z * (1.0 - blend) + nz * blend
                );
            } else if (speed.value > 1.1) {
                // classic soft assist
                Vec3 v = mc.player.getDeltaMovement();
                double len = Math.sqrt(v.x * v.x + v.z * v.z);
                if (len > 0.01 && len < 0.55 * speed.value) {
                    float yaw = mc.player.getYRot() * 0.017453292f;
                    double target = 0.26 * speed.value;
                    double nx = -Math.sin(yaw) * target;
                    double nz = Math.cos(yaw) * target;
                    mc.player.setDeltaMovement(v.x * 0.75 + nx * 0.25, v.y, v.z * 0.75 + nz * 0.25);
                }
            }
        }
    }

    @Override
    public String info() {
        return strafe.value ? "Strafe " + String.format("%.1fx", speed.value) : String.format("%.1fx", speed.value);
    }
}
