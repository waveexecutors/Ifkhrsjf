package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import net.minecraft.world.phys.Vec3;

/**
 * Highly configurable Bunny Hop.
 * Speed, jump height, auto-sprint and timing are all adjustable.
 */
public class BhopFeature extends Feature {
    public static BhopFeature I;

    private final Setting.Num speed = num("Speed Multiplier", 1.4, 1.0, 3.0, 0.05);
    private final Setting.Num jumpHeight = num("Jump Height", 0.42, 0.3, 0.8, 0.01);
    private final Setting.Bool autoSprint = bool("Auto Sprint", true);
    private final Setting.Bool onlyForward = bool("Only When Moving", true);
    private final Setting.Num timer = num("Timer Boost", 1.0, 1.0, 1.5, 0.05);
    private final Setting.Bool lowhop = bool("Lowhop Mode", false);

    private int groundTicks = 0;

    public BhopFeature() {
        super("Bhop", "Super configurable bunny hop. Tune speed, height, timer and modes for any server.", Category.MOVEMENT);
        I = this;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) return;
        if (mc.player.getAbilities().flying || mc.player.isPassenger() || mc.player.isInWater() || mc.player.isInLava()) return;

        boolean moving = mc.player.input.getMoveVector().x != 0 || mc.player.input.getMoveVector().y != 0;
        if (onlyForward.value && !moving) return;

        if (autoSprint.value && moving && !mc.player.isSprinting()) {
            mc.player.setSprinting(true);
        }

        if (mc.player.onGround()) {
            groundTicks++;
            if (groundTicks >= 1) {
                // jump
                double jh = lowhop.value ? 0.3 : jumpHeight.value;
                Vec3 v = mc.player.getDeltaMovement();
                mc.player.setDeltaMovement(v.x, jh, v.z);
                mc.player.jumpFromGround(); // ensures animation / sound consistency

                // horizontal boost
                float yaw = mc.player.getYRot() * 0.017453292f;
                double mx = -Math.sin(yaw) * (speed.value - 1.0) * 0.2;
                double mz = Math.cos(yaw) * (speed.value - 1.0) * 0.2;
                mc.player.setDeltaMovement(
                        mc.player.getDeltaMovement().x + mx,
                        mc.player.getDeltaMovement().y,
                        mc.player.getDeltaMovement().z + mz
                );
                groundTicks = 0;
            }
        } else {
            groundTicks = 0;
            // slight air strafe assist
            if (moving && speed.value > 1.1) {
                Vec3 v = mc.player.getDeltaMovement();
                double len = Math.sqrt(v.x * v.x + v.z * v.z);
                if (len > 0.01 && len < 0.6 * speed.value) {
                    float yaw = mc.player.getYRot() * 0.017453292f;
                    double target = 0.28 * speed.value;
                    double nx = -Math.sin(yaw) * target;
                    double nz = Math.cos(yaw) * target;
                    mc.player.setDeltaMovement(v.x * 0.7 + nx * 0.3, v.y, v.z * 0.7 + nz * 0.3);
                }
            }
        }
    }

    @Override
    public String info() {
        return String.format("%.1fx", speed.value);
    }
}
