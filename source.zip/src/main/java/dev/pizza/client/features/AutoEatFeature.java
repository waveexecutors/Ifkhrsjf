package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;

public class AutoEatFeature extends Feature {
    private final Setting.Num hunger = num("Hunger Threshold", 14, 1, 19, 1);
    private final Setting.Bool gapple = bool("Prefer Golden Apple", false);

    public AutoEatFeature() {
        super("AutoEat", "Eats food automatically when hunger drops below the threshold.", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.gameMode == null) return;
        if (mc.player.getFoodData().getFoodLevel() > hunger.i()) return;
        if (mc.player.isUsingItem()) return;

        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getItem(i);
            if (s.isEmpty() || !s.getItem().components().has(net.minecraft.core.component.DataComponents.FOOD)) continue;
            boolean isGapple = s.is(net.minecraft.world.item.Items.GOLDEN_APPLE) || s.is(net.minecraft.world.item.Items.ENCHANTED_GOLDEN_APPLE);
            if (gapple.value && !isGapple) continue;
            int prev = mc.player.getInventory().selected;
            mc.player.getInventory().selected = i;
            mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
            mc.player.getInventory().selected = prev;
            break;
        }
    }
}
