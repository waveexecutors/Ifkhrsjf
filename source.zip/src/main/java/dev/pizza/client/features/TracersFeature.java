package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import dev.pizza.client.util.Draw;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Tracers – lines from the crosshair / bottom of screen to players.
 */
public class TracersFeature extends Feature {
    public static TracersFeature I;

    private final Setting.Bool players = bool("Players", true);
    private final Setting.Num range = num("Range", 128, 16, 256, 8);
    private final Setting.Bool fromCrosshair = bool("From Crosshair", true);
    private final Setting.Num thickness = num("Thickness", 1, 1, 3, 1);

    public TracersFeature() {
        super("Tracers", "Draws lines to other players so you never lose track of them.", Category.RENDER);
        I = this;
    }

    public void renderTracers(GuiGraphics g) {
        if (!enabled || mc.player == null || mc.level == null || mc.gameRenderer == null) return;

        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        int originX = sw / 2;
        int originY = fromCrosshair.value ? sh / 2 : sh - 2;

        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof Player p) || p == mc.player) continue;
            if (!players.value) continue;
            if (p.distanceTo(mc.player) > range.value) continue;

            Vec3 cam = mc.gameRenderer.getMainCamera().getPosition();
            Vec3 pos = p.position().add(0, p.getBbHeight() * 0.5, 0);
            double dx = pos.x - cam.x;
            double dy = pos.y - cam.y;
            double dz = pos.z - cam.z;

            float yaw = mc.gameRenderer.getMainCamera().getYRot();
            float pitch = mc.gameRenderer.getMainCamera().getXRot();
            double cosYaw = Math.cos(Math.toRadians(-yaw));
            double sinYaw = Math.sin(Math.toRadians(-yaw));
            double cosPitch = Math.cos(Math.toRadians(-pitch));
            double sinPitch = Math.sin(Math.toRadians(-pitch));

            double x1 = dx * cosYaw + dz * sinYaw;
            double z1 = -dx * sinYaw + dz * cosYaw;
            double y1 = dy * cosPitch - z1 * sinPitch;
            double z2 = dy * sinPitch + z1 * cosPitch;

            if (z2 < 0.1) continue;

            double scale = (sw / 2.0) / (Math.tan(Math.toRadians(70) / 2.0) * z2);
            int sx = (int) (sw / 2.0 + x1 * scale);
            int sy = (int) (sh / 2.0 - y1 * scale);

            int color = Draw.ACCENT;
            if (p.getHealth() < 8) color = Draw.DANGER;

            // simple line (Bresenham-ish fill)
            drawLine(g, originX, originY, sx, sy, color, thickness.i());
        }
    }

    private void drawLine(GuiGraphics g, int x0, int y0, int x1, int y1, int color, int t) {
        int dx = Math.abs(x1 - x0);
        int dy = Math.abs(y1 - y0);
        int sx = x0 < x1 ? 1 : -1;
        int sy = y0 < y1 ? 1 : -1;
        int err = dx - dy;
        int x = x0, y = y0;
        while (true) {
            g.fill(x - t / 2, y - t / 2, x + t / 2 + 1, y + t / 2 + 1, color);
            if (x == x1 && y == y1) break;
            int e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x += sx; }
            if (e2 < dx) { err += dx; y += sy; }
        }
    }

    @Override
    public String info() {
        return "Lines";
    }
}
