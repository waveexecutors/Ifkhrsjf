package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;

/**
 * Mild reach extension via creative-style interaction range when possible.
 * Values above ~3.1–3.2 are easily noticeable on most servers – keep low.
 */
public class ReachFeature extends Feature {
    private final Setting.Num blockReach = num("Block Reach", 4.5, 4.5, 6.0, 0.1);
    private final Setting.Num entityReach = num("Entity Reach", 3.0, 3.0, 4.0, 0.05);

    public ReachFeature() {
        super("Reach", "Slightly extends block and entity interaction range. Keep values low.", Category.COMBAT);
    }

    // Actual reach injection usually needs mixins into game mode / player.
    // We expose settings so a future mixin can read them; for now document intent.
    public double block() { return enabled ? blockReach.value : 4.5; }
    public double entity() { return enabled ? entityReach.value : 3.0; }

    public static ReachFeature I;

    {
        I = this;
    }

    @Override
    public String info() {
        return String.format("%.1f/%.1f", blockReach.value, entityReach.value);
    }
}
