package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import net.minecraft.world.phys.Vec3;

public class SpiderFeature extends Feature {
    private final Setting.Num climbSpeed = num("Climb Speed", 0.2, 0.1, 0.5, 0.05);

    public SpiderFeature() {
        super("Spider", "Climb walls when touching them.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.player.horizontalCollision) {
            Vec3 v = mc.player.getDeltaMovement();
            mc.player.setDeltaMovement(v.x, climbSpeed.value, v.z);
        }
    }

    @Override
    public String info() {
        return climbSpeed.text();
    }
}
