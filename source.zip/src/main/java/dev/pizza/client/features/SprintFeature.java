package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;

public class SprintFeature extends Feature {
    public SprintFeature() {
        super("Sprint", "Holds sprint for you whenever you move forward.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.player.input.getMoveVector().y > 0 && !mc.player.isSprinting() && !mc.player.horizontalCollision) {
            mc.player.setSprinting(true);
        }
    }
}
