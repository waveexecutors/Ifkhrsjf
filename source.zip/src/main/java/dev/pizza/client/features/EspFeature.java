package dev.pizza.client.features;

import dev.pizza.client.feature.Category;
import dev.pizza.client.feature.Feature;
import dev.pizza.client.feature.Setting;
import dev.pizza.client.util.Draw;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * 2D ESP – screen-space boxes + distance tags for other players.
 * Clean premium look matching the ClickGUI theme.
 */
public class EspFeature extends Feature {
    public static EspFeature I;

    private final Setting.Bool players = bool("Players", true);
    private final Setting.Bool self = bool("Show Self", false);
    private final Setting.Num range = num("Range", 128, 16, 256, 8);
    private final Setting.Bool distance = bool("Distance", true);
    private final Setting.Bool health = bool("Health", true);
    private final Setting.Bool filled = bool("Filled Box", false);

    public EspFeature() {
        super("ESP", "2D player ESP with boxes, distance and health. Premium screen-space overlay.", Category.RENDER);
        I = this;
    }

    @Override
    public void onTick() {
        // rendering is done in Hud via world-to-screen projection helper
    }

    @Override
    public int hud(GuiGraphics g, int x, int y) {
        // ESP is drawn in full screen space, not the left column
        return 0;
    }

    /** Called from Hud to draw ESP overlays. */
    public void renderEsp(GuiGraphics g) {
        if (!enabled || mc.player == null || mc.level == null || mc.gameRenderer == null) return;

        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();

        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof Player p)) continue;
            if (!self.value && p == mc.player) continue;
            if (!players.value) continue;
            if (p.distanceTo(mc.player) > range.value) continue;

            // Simple approximate screen projection using camera
            Vec3 cam = mc.gameRenderer.getMainCamera().position();
            Vec3 pos = p.position().add(0, p.getBbHeight() / 2.0, 0);
            double dx = pos.x - cam.x;
            double dy = pos.y - cam.y;
            double dz = pos.z - cam.z;

            // Very rough FOV projection (good enough for utility)
            float yaw = mc.gameRenderer.getMainCamera().yRot();
            float pitch = mc.gameRenderer.getMainCamera().xRot();
            double cosYaw = Math.cos(Math.toRadians(-yaw));
            double sinYaw = Math.sin(Math.toRadians(-yaw));
            double cosPitch = Math.cos(Math.toRadians(-pitch));
            double sinPitch = Math.sin(Math.toRadians(-pitch));

            double x1 = dx * cosYaw + dz * sinYaw;
            double z1 = -dx * sinYaw + dz * cosYaw;
            double y1 = dy * cosPitch - z1 * sinPitch;
            double z2 = dy * sinPitch + z1 * cosPitch;

            if (z2 < 0.1) continue; // behind camera

            double scale = (sw / 2.0) / (Math.tan(Math.toRadians(70) / 2.0) * z2); // approx FOV
            int sx = (int) (sw / 2.0 + x1 * scale);
            int sy = (int) (sh / 2.0 - y1 * scale);

            int boxH = (int) Math.max(18, (p.getBbHeight() * scale));
            int boxW = (int) Math.max(10, boxH * 0.45);
            int left = sx - boxW / 2;
            int top = sy - boxH / 2;
            int right = left + boxW;
            int bottom = top + boxH;

            // clamp a bit so offscreen is not drawn fully
            if (right < 0 || left > sw || bottom < 0 || top > sh) continue;

            int color = Draw.ACCENT;
            if (p.getHealth() < 8) color = Draw.DANGER;
            else if (p.getHealth() < 14) color = 0xFFFBBF24;

            if (filled.value) {
                g.fill(left, top, right, bottom, (color & 0x00FFFFFF) | 0x33000000);
            }
            // outline
            g.fill(left, top, right, top + 1, color);
            g.fill(left, bottom - 1, right, bottom, color);
            g.fill(left, top, left + 1, bottom, color);
            g.fill(right - 1, top, right, bottom, color);

            // corner accents
            int c = 4;
            g.fill(left, top, left + c, top + 1, 0xFFFFFFFF);
            g.fill(left, top, left + 1, top + c, 0xFFFFFFFF);
            g.fill(right - c, top, right, top + 1, 0xFFFFFFFF);
            g.fill(right - 1, top, right, top + c, 0xFFFFFFFF);

            String tag = p.getName().getString();
            if (distance.value) {
                tag += " §7" + String.format("%.0f", p.distanceTo(mc.player)) + "m";
            }
            if (health.value) {
                tag += " §c" + String.format("%.0f", p.getHealth());
            }
            int tw = Draw.width(tag);
            Draw.text(g, tag, sx - tw / 2, top - 11, Draw.TEXT);
        }
    }

    @Override
    public String info() {
        return "2D";
    }
}
