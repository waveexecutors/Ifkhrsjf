package dev.pizza.client.feature;

public enum Category {
    RENDER("Render"),
    COMBAT("Combat"),
    MOVEMENT("Movement"),
    PLAYER("Player"),
    WORLD("World"),
    MISC("Misc");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
