package dev.pizza.client.feature;

import java.util.function.Supplier;

public abstract class Setting {
    public final String name;
    public Runnable onChange = () -> {};

    protected Setting(String name) {
        this.name = name;
    }

    public static final class Bool extends Setting {
        public boolean value;

        public Bool(String name, boolean value) {
            super(name);
            this.value = value;
        }

        public void toggle() {
            value = !value;
            onChange.run();
        }
    }

    public static final class Num extends Setting {
        public double value;
        public final double min, max, step;

        public Num(String name, double value, double min, double max, double step) {
            super(name);
            this.value = value;
            this.min = min;
            this.max = max;
            this.step = step;
        }

        public void set(double v) {
            v = Math.max(min, Math.min(max, v));
            v = Math.round(v / step) * step;
            if (v != value) {
                value = v;
                onChange.run();
            }
        }

        public int i() {
            return (int) Math.round(value);
        }

        public String text() {
            return step >= 1 ? String.valueOf(i()) : String.format("%.1f", value);
        }
    }

    public static final class Button extends Setting {
        public final Runnable action;
        public final Supplier<String> label;

        public Button(String name, Supplier<String> label, Runnable action) {
            super(name);
            this.label = label;
            this.action = action;
        }
    }
}
