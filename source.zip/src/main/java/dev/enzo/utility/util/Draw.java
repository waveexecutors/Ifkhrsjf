package dev.enzo.utility.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public final class Draw {
    public static final int ACCENT = 0xFF8B5CF6;
    public static final int ACCENT_DARK = 0xFF5B3FB8;
    public static final int HEADER = 0xFF181822;
    public static final int BODY = 0xE60F0F16;
    public static final int TRACK = 0xFF2A2A38;
    public static final int TEXT = 0xFFE5E7EB;
    public static final int DIM = 0xFF9CA3AF;

    private Draw() {}

    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    public static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    public static void text(GuiGraphics g, String s, int x, int y, int color) {
        g.drawString(Minecraft.getInstance().font, s, x, y, color);
    }

    public static int width(String s) {
        return Minecraft.getInstance().font.width(s);
    }

    public static void hudBox(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, 0x99000000);
        g.fill(x, y, x + 2, y + h, ACCENT);
    }

    public static String pretty(String path) {
        StringBuilder sb = new StringBuilder();
        for (String part : path.split("_")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }
}
