package dev.enzo.utility.util;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

public final class Chat {
    private Chat() {}

    public static void info(String msg) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            mc.player.displayClientMessage(Component.literal("§d[Enzo] §f" + msg), false);
        }
    }

    /** Dimension name without namespace, e.g. "overworld", "the_nether". */
    public static String dimension() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return "unknown";
        String s = mc.level.dimension().toString();
        int i = s.lastIndexOf('/');
        if (i >= 0) s = s.substring(i + 1);
        s = s.replace("]", "").trim();
        if (s.startsWith("minecraft:")) s = s.substring(10);
        return s;
    }
}
