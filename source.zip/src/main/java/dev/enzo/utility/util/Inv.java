package dev.enzo.utility.util;

import java.util.function.Predicate;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

public final class Inv {
    private Inv() {}

    private static Minecraft mc() {
        return Minecraft.getInstance();
    }

    public static String id(ItemStack s) {
        return BuiltInRegistries.ITEM.getKey(s.getItem()).toString();
    }

    /** Player inventory index (0-8 hotbar, 9-35 main) to container menu slot. */
    public static int menuSlot(int invSlot) {
        return invSlot < 9 ? 36 + invSlot : invSlot;
    }

    public static int findHotbar(Predicate<ItemStack> p) {
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc().player.getInventory().getItem(i);
            if (!s.isEmpty() && p.test(s)) return i;
        }
        return -1;
    }

    public static int findInv(Predicate<ItemStack> p) {
        for (int i = 0; i < 36; i++) {
            ItemStack s = mc().player.getInventory().getItem(i);
            if (!s.isEmpty() && p.test(s)) return i;
        }
        return -1;
    }

    public static void select(int hotbarSlot) {
        mc().player.getInventory().setSelectedSlot(hotbarSlot);
    }

    public static int selected() {
        return mc().player.getInventory().getSelectedSlot();
    }

    /** Swap an inventory slot with a hotbar slot using the inventory menu. */
    public static void swap(int invSlot, int hotbarSlot) {
        Minecraft m = mc();
        m.gameMode.handleInventoryMouseClick(m.player.inventoryMenu.containerId, menuSlot(invSlot), hotbarSlot, ClickType.SWAP, m.player);
    }

    /** Right-click the top face of a block with the held item. */
    public static void useOnTop(BlockPos p) {
        Minecraft m = mc();
        BlockHitResult hit = new BlockHitResult(new Vec3(p.getX() + 0.5, p.getY() + 1.0, p.getZ() + 0.5), Direction.UP, p, false);
        m.gameMode.useItemOn(m.player, InteractionHand.MAIN_HAND, hit);
        m.player.swing(InteractionHand.MAIN_HAND);
    }
}
