package dev.enzo.utility.mixin;

import dev.enzo.utility.features.XrayFeature;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Xray: blocks that are not on the "visible" list are made invisible and
 * non-occluding, so the faces of the blocks we do want to see are never culled.
 * Handlers take no arguments on purpose so they stay valid even if vanilla
 * changes the parameter lists of the target methods.
 */
@Mixin(BlockBehaviour.BlockStateBase.class)
public class BlockStateBaseMixin {

    @Inject(method = "getRenderShape", at = @At("HEAD"), cancellable = true, require = 0)
    private void enzo$renderShape(CallbackInfoReturnable<RenderShape> cir) {
        if (XrayFeature.active && XrayFeature.isHidden((BlockState) (Object) this)) {
            cir.setReturnValue(RenderShape.INVISIBLE);
        }
    }

    @Inject(method = "canOcclude", at = @At("HEAD"), cancellable = true, require = 0)
    private void enzo$canOcclude(CallbackInfoReturnable<Boolean> cir) {
        if (XrayFeature.active && XrayFeature.isHidden((BlockState) (Object) this)) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "isSolidRender", at = @At("HEAD"), cancellable = true, require = 0)
    private void enzo$solidRender(CallbackInfoReturnable<Boolean> cir) {
        if (XrayFeature.active && XrayFeature.isHidden((BlockState) (Object) this)) {
            cir.setReturnValue(false);
        }
    }
}
