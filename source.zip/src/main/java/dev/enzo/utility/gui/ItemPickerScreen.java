package dev.enzo.utility.gui;

import dev.enzo.utility.features.AutoSellFeature;
import dev.enzo.utility.util.Draw;
import dev.enzo.utility.util.Inv;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;

/** Window that lists the item types in your inventory; click to add/remove them from Auto Sell. */
public class ItemPickerScreen extends Screen {
    private static final int COLS = 8, CELL = 30, PAD = 10;

    private final Screen parent;
    private final List<ItemStack> stacks = new ArrayList<>();
    private final List<Integer> totals = new ArrayList<>();
    private boolean pl;

    public ItemPickerScreen(Screen parent) {
        super(Component.literal("Auto Sell"));
        this.parent = parent;
        long w = GLFW.glfwGetCurrentContext();
        pl = GLFW.glfwGetMouseButton(w, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;

        Minecraft mc = Minecraft.getInstance();
        Map<String, Integer> idx = new LinkedHashMap<>();
        if (mc.player != null) {
            for (int i = 0; i < 36; i++) {
                ItemStack s = mc.player.getInventory().getItem(i);
                if (s.isEmpty()) continue;
                String id = Inv.id(s);
                Integer at = idx.get(id);
                if (at == null) {
                    idx.put(id, stacks.size());
                    stacks.add(s.copy());
                    totals.add(s.getCount());
                } else {
                    totals.set(at, totals.get(at) + s.getCount());
                }
            }
        }
    }

    public boolean isPauseScreen() {
        return false;
    }

    private void back() {
        Minecraft.getInstance().setScreen(parent);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        long win = GLFW.glfwGetCurrentContext();
        boolean l = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean click = l && !pl;
        pl = l;

        g.fill(0, 0, width, height, 0xA0000000);

        int rows = Math.max(1, (stacks.size() + COLS - 1) / COLS);
        int ww = COLS * CELL + PAD * 2;
        int gridH = rows * CELL;
        int wh = 24 + 18 + gridH + 34;
        int x0 = (width - ww) / 2;
        int y0 = (height - wh) / 2;

        g.fill(x0 - 1, y0 - 1, x0 + ww + 1, y0 + wh + 1, 0x50000000);
        g.fill(x0, y0, x0 + ww, y0 + wh, Draw.BODY);
        g.fill(x0, y0, x0 + ww, y0 + 22, Draw.HEADER);
        g.fill(x0, y0 + 20, x0 + ww, y0 + 22, Draw.ACCENT);
        Draw.text(g, "AUTO SELL  -  choose item(s) to sell with /sell", x0 + 8, y0 + 7, Draw.TEXT);
        Draw.text(g, "Click an item to select / unselect it. Selected: " + AutoSellFeature.ITEMS.size(), x0 + PAD, y0 + 28, Draw.DIM);

        int gy = y0 + 42;
        String tooltip = null;
        if (stacks.isEmpty()) {
            Draw.text(g, "Your inventory is empty.", x0 + PAD, gy + 6, Draw.DIM);
        }
        for (int i = 0; i < stacks.size(); i++) {
            ItemStack s = stacks.get(i);
            int cx = x0 + PAD + (i % COLS) * CELL;
            int cy = gy + (i / COLS) * CELL;
            String id = Inv.id(s);
            boolean sel = AutoSellFeature.ITEMS.contains(id);
            boolean hov = Draw.inside(mx, my, cx, cy, CELL - 2, CELL - 2);
            g.fill(cx, cy, cx + CELL - 2, cy + CELL - 2, sel ? 0xFF2D2354 : (hov ? 0xFF2A2A38 : 0xFF1A1A24));
            if (sel) {
                g.fill(cx, cy, cx + CELL - 2, cy + 1, Draw.ACCENT);
                g.fill(cx, cy + CELL - 3, cx + CELL - 2, cy + CELL - 2, Draw.ACCENT);
                g.fill(cx, cy, cx + 1, cy + CELL - 2, Draw.ACCENT);
                g.fill(cx + CELL - 3, cy, cx + CELL - 2, cy + CELL - 2, Draw.ACCENT);
            }
            g.renderItem(s, cx + 6, cy + 4);
            String cnt = String.valueOf(totals.get(i));
            Draw.text(g, cnt, cx + CELL - 4 - Draw.width(cnt), cy + CELL - 12, Draw.TEXT);
            if (hov) {
                tooltip = s.getHoverName().getString() + (sel ? "  (selected)" : "");
                if (click) {
                    if (!AutoSellFeature.ITEMS.remove(id)) AutoSellFeature.ITEMS.add(id);
                }
            }
        }

        int by = y0 + wh - 26;
        int bw = 70;
        int clearX = x0 + ww - PAD - bw * 2 - 8;
        int doneX = x0 + ww - PAD - bw;
        boolean hClear = Draw.inside(mx, my, clearX, by, bw, 16);
        boolean hDone = Draw.inside(mx, my, doneX, by, bw, 16);
        g.fill(clearX, by, clearX + bw, by + 16, hClear ? 0xFF3A2A2A : 0xFF2A2A38);
        g.fill(doneX, by, doneX + bw, by + 16, hDone ? Draw.ACCENT : Draw.ACCENT_DARK);
        Draw.text(g, "Clear", clearX + (bw - Draw.width("Clear")) / 2, by + 4, Draw.TEXT);
        Draw.text(g, "Done", doneX + (bw - Draw.width("Done")) / 2, by + 4, 0xFFFFFFFF);
        if (click && hClear) AutoSellFeature.ITEMS.clear();
        if (click && hDone) {
            back();
            return;
        }

        if (tooltip != null) {
            int tw = Draw.width(tooltip) + 10;
            int tx = Math.min(mx + 10, width - tw - 2);
            g.fill(tx, my + 12, tx + tw, my + 26, 0xF0101018);
            g.fill(tx, my + 12, tx + 2, my + 26, Draw.ACCENT);
            Draw.text(g, tooltip, tx + 6, my + 15, Draw.TEXT);
        }
    }
}
