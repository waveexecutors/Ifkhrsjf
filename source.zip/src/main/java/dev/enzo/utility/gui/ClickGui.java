package dev.enzo.utility.gui;

import dev.enzo.utility.feature.Category;
import dev.enzo.utility.feature.Feature;
import dev.enzo.utility.feature.Features;
import dev.enzo.utility.feature.Setting;
import dev.enzo.utility.util.Draw;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/**
 * Modern dark ClickGUI. Opened with Right Shift.
 * Left click a feature = toggle, right click = show its settings, drag a header to move a panel,
 * right click a header to collapse it. Input is polled from GLFW so it does not depend on
 * Minecraft's changing mouse/keyboard event signatures.
 */
public class ClickGui extends Screen {
    private static final int PW = 150, HH = 20, RH = 18, BR = 16, NR = 25;

    /** category name -> {x, y, open(1/0)} */
    public static final Map<String, int[]> LAYOUT = new LinkedHashMap<>();
    private static final List<Panel> PANELS = new ArrayList<>();
    private static final Set<Feature> EXPANDED = new HashSet<>();
    private static final Map<Feature, Float> ANIM = new HashMap<>();

    private static final class Panel {
        final Category cat;
        int x, y;
        boolean open;

        Panel(Category cat, int x, int y, boolean open) {
            this.cat = cat;
            this.x = x;
            this.y = y;
            this.open = open;
        }
    }

    private boolean pl, pr, prs;
    private Panel drag;
    private int dox, doy;
    private Setting.Num slider;
    private int sliderX, sliderW;

    public ClickGui() {
        super(Component.literal("Enzo Utility"));
        long w = GLFW.glfwGetCurrentContext();
        pl = GLFW.glfwGetMouseButton(w, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        pr = GLFW.glfwGetMouseButton(w, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        prs = GLFW.glfwGetKey(w, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        ensurePanels();
    }

    private static void ensurePanels() {
        if (!PANELS.isEmpty()) return;
        int i = 0;
        for (Category c : Category.values()) {
            if (Features.byCategory(c).isEmpty()) continue;
            int[] d = LAYOUT.get(c.name());
            if (d != null) PANELS.add(new Panel(c, d[0], d[1], d[2] == 1));
            else PANELS.add(new Panel(c, 14 + i * (PW + 10), 28, true));
            i++;
        }
    }

    public static void syncLayout() {
        for (Panel p : PANELS) LAYOUT.put(p.cat.name(), new int[] {p.x, p.y, p.open ? 1 : 0});
    }

    private static int rowH(Setting s) {
        return s instanceof Setting.Num ? NR : BR;
    }

    private int panelH(Panel p) {
        int h = HH;
        if (!p.open) return h;
        for (Feature f : Features.byCategory(p.cat)) {
            h += RH;
            if (EXPANDED.contains(f)) for (Setting s : f.settings) h += rowH(s);
        }
        return h + 2;
    }

    private void closeGui() {
        Features.save();
        Minecraft.getInstance().setScreen(null);
    }

    public boolean isPauseScreen() {
        return false;
    }

    public void removed() {
        Features.save();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        long win = GLFW.glfwGetCurrentContext();
        boolean l = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean rs = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        boolean lClick = l && !pl;
        boolean rClick = r && !pr;
        pl = l;
        pr = r;
        if (rs && !prs) {
            closeGui();
            return;
        }
        prs = rs;

        g.fill(0, 0, width, height, 0x88000000);
        String title = "ENZO UTILITY   |   Right Shift to close   |   L-click toggle, R-click settings";
        Draw.text(g, title, (width - Draw.width(title)) / 2, 8, Draw.DIM);

        // topmost panel under cursor
        Panel top = null;
        for (int i = PANELS.size() - 1; i >= 0; i--) {
            Panel p = PANELS.get(i);
            if (Draw.inside(mx, my, p.x, p.y, PW, panelH(p))) {
                top = p;
                break;
            }
        }
        if (top != null && (lClick || rClick)) {
            PANELS.remove(top);
            PANELS.add(top);
        }

        if (!l) {
            drag = null;
            slider = null;
        }
        if (drag != null) {
            drag.x = Math.max(0, Math.min(width - PW, mx - dox));
            drag.y = Math.max(0, Math.min(height - HH, my - doy));
        }
        if (slider != null) {
            double t = (mx - sliderX) / (double) sliderW;
            slider.set(slider.min + t * (slider.max - slider.min));
        }

        Feature hovered = null;
        for (Panel p : new ArrayList<>(PANELS)) {
            boolean act = p == top;
            int h = panelH(p);

            g.fill(p.x - 1, p.y - 1, p.x + PW + 1, p.y + h + 1, 0x40000000);
            g.fill(p.x, p.y, p.x + PW, p.y + HH, Draw.HEADER);
            g.fill(p.x, p.y + HH - 2, p.x + PW, p.y + HH, Draw.ACCENT);
            Draw.text(g, p.cat.label.toUpperCase(), p.x + 8, p.y + 6, Draw.TEXT);
            Draw.text(g, p.open ? "-" : "+", p.x + PW - 12, p.y + 6, Draw.DIM);

            if (act && Draw.inside(mx, my, p.x, p.y, PW, HH)) {
                if (lClick) {
                    drag = p;
                    dox = mx - p.x;
                    doy = my - p.y;
                } else if (rClick) {
                    p.open = !p.open;
                }
            }
            if (!p.open) continue;

            g.fill(p.x, p.y + HH, p.x + PW, p.y + h, Draw.BODY);
            int ry = p.y + HH;
            for (Feature f : Features.byCategory(p.cat)) {
                boolean hov = act && Draw.inside(mx, my, p.x, ry, PW, RH);
                float a = ANIM.getOrDefault(f, f.enabled ? 1f : 0f);
                a += ((f.enabled ? 1f : 0f) - a) * 0.25f;
                ANIM.put(f, a);

                if (hov) {
                    hovered = f;
                    g.fill(p.x, ry, p.x + PW, ry + RH, 0x22FFFFFF);
                    if (lClick) {
                        f.toggle();
                        if (f.enabled) f.onToggledByUser();
                    } else if (rClick && !f.settings.isEmpty()) {
                        if (!EXPANDED.remove(f)) EXPANDED.add(f);
                    }
                }
                if (a > 0.03f) g.fill(p.x, ry, p.x + 2, ry + RH, Draw.lerp(0xFF2A2A38, Draw.ACCENT, a));
                Draw.text(g, f.name, p.x + 8, ry + 5, Draw.lerp(Draw.DIM, 0xFFFFFFFF, a));
                if (!f.settings.isEmpty()) {
                    Draw.text(g, EXPANDED.contains(f) ? "v" : "...", p.x + PW - 44, ry + 5, Draw.DIM);
                }
                // switch
                int sx = p.x + PW - 26, sy = ry + 5;
                g.fill(sx, sy, sx + 18, sy + 8, Draw.lerp(Draw.TRACK, Draw.ACCENT, a));
                int kx = sx + 1 + Math.round(a * 10f);
                g.fill(kx, sy + 1, kx + 6, sy + 7, 0xFFFFFFFF);
                ry += RH;

                if (EXPANDED.contains(f)) {
                    for (Setting s : f.settings) {
                        int sh = rowH(s);
                        g.fill(p.x, ry, p.x + PW, ry + sh, 0x40000000);
                        g.fill(p.x + 4, ry, p.x + 5, ry + sh, Draw.ACCENT_DARK);
                        boolean shov = act && Draw.inside(mx, my, p.x, ry, PW, sh);
                        if (shov) g.fill(p.x + 5, ry, p.x + PW, ry + sh, 0x14FFFFFF);

                        if (s instanceof Setting.Bool b) {
                            Draw.text(g, b.name, p.x + 10, ry + 4, Draw.TEXT);
                            int bx = p.x + PW - 16;
                            g.fill(bx, ry + 3, bx + 9, ry + 12, Draw.TRACK);
                            if (b.value) g.fill(bx + 2, ry + 5, bx + 7, ry + 10, Draw.ACCENT);
                            if (shov && lClick) b.toggle();
                        } else if (s instanceof Setting.Num n) {
                            Draw.text(g, n.name, p.x + 10, ry + 3, Draw.TEXT);
                            String v = n.text();
                            Draw.text(g, v, p.x + PW - 8 - Draw.width(v), ry + 3, Draw.DIM);
                            int bx = p.x + 10, bw = PW - 20;
                            g.fill(bx, ry + 16, bx + bw, ry + 19, Draw.TRACK);
                            int fw = (int) Math.round((n.value - n.min) / (n.max - n.min) * bw);
                            g.fill(bx, ry + 16, bx + fw, ry + 19, Draw.ACCENT);
                            g.fill(bx + fw - 2, ry + 14, bx + fw + 2, ry + 21, 0xFFFFFFFF);
                            if (shov && lClick) {
                                slider = n;
                                sliderX = bx;
                                sliderW = bw;
                            }
                        } else if (s instanceof Setting.Button bt) {
                            Draw.text(g, bt.label.get(), p.x + 10, ry + 4, Draw.ACCENT);
                            if (shov && lClick) bt.action.run();
                        }
                        ry += sh;
                    }
                }
            }
        }

        if (hovered != null) {
            String d = hovered.description;
            int tw = Draw.width(d) + 10;
            int tx = Math.min(mx + 10, width - tw - 2);
            int ty = my + 12;
            g.fill(tx, ty, tx + tw, ty + 14, 0xF0101018);
            g.fill(tx, ty, tx + 2, ty + 14, Draw.ACCENT);
            Draw.text(g, d, tx + 6, ty + 3, Draw.TEXT);
        }
    }
}
