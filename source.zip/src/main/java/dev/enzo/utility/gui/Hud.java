package dev.enzo.utility.gui;

import dev.enzo.utility.feature.Feature;
import dev.enzo.utility.feature.Features;
import dev.enzo.utility.features.HudFeature;
import dev.enzo.utility.util.Draw;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public final class Hud {
    private Hud() {}

    public static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        // left column: per-feature overlays (coords, ore finder, base finder, death coords)
        int y = 4;
        for (Feature f : Features.ALL) {
            if (f.enabled) y += f.hud(g, 4, y);
        }

        // right column: arraylist
        if (HudFeature.I != null && HudFeature.I.enabled && HudFeature.I.arraylist.value) {
            int sw = mc.getWindow().getGuiScaledWidth();
            List<String> lines = new ArrayList<>();
            for (Feature f : Features.ALL) {
                if (!f.enabled || f instanceof HudFeature) continue;
                String info = f.info();
                lines.add(info == null ? f.name : f.name + " §7" + info);
            }
            lines.sort(Comparator.comparingInt((String s) -> Draw.width(s)).reversed());
            int ry = 4;
            for (String s : lines) {
                int w = Draw.width(s);
                g.fill(sw - w - 8, ry, sw - 2, ry + 11, 0x99000000);
                g.fill(sw - 2, ry, sw, ry + 11, Draw.ACCENT);
                Draw.text(g, s, sw - w - 5, ry + 2, Draw.TEXT);
                ry += 11;
            }
        }
    }
}
