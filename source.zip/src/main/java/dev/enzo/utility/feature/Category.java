package dev.enzo.utility.feature;

public enum Category {
    RENDER("Render"),
    AUTOMATION("Automation"),
    SMP("SMP"),
    MISC("Misc");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
