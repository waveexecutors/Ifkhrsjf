package dev.enzo.utility.feature;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.enzo.utility.features.AntiAfkFeature;
import dev.enzo.utility.features.AutoEatFeature;
import dev.enzo.utility.features.AutoFarmFeature;
import dev.enzo.utility.features.AutoSellFeature;
import dev.enzo.utility.features.AutoTotemFeature;
import dev.enzo.utility.features.BaseFinderFeature;
import dev.enzo.utility.features.DeathCoordsFeature;
import dev.enzo.utility.features.FullbrightFeature;
import dev.enzo.utility.features.HudFeature;
import dev.enzo.utility.features.OreFinderFeature;
import dev.enzo.utility.features.PlayerAlertFeature;
import dev.enzo.utility.features.SprintFeature;
import dev.enzo.utility.features.XrayFeature;
import dev.enzo.utility.gui.ClickGui;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Features {
    public static final Logger LOG = LoggerFactory.getLogger("EnzoUtility");
    public static final List<Feature> ALL = new ArrayList<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Set<String> BROKEN = new HashSet<>();

    private Features() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("enzoutility.json");
    }

    public static void init() {
        ALL.add(new XrayFeature());
        ALL.add(new FullbrightFeature());
        ALL.add(new OreFinderFeature());
        ALL.add(new AutoFarmFeature());
        ALL.add(new AutoSellFeature());
        ALL.add(new AutoEatFeature());
        ALL.add(new AutoTotemFeature());
        ALL.add(new BaseFinderFeature());
        ALL.add(new PlayerAlertFeature());
        ALL.add(new DeathCoordsFeature());
        ALL.add(new AntiAfkFeature());
        ALL.add(new SprintFeature());
        ALL.add(new HudFeature());
    }

    public static List<Feature> byCategory(Category c) {
        List<Feature> out = new ArrayList<>();
        for (Feature f : ALL) if (f.category == c) out.add(f);
        return out;
    }

    public static void tick() {
        for (Feature f : ALL) {
            if (!f.enabled) continue;
            try {
                f.onTick();
            } catch (Throwable t) {
                if (BROKEN.add(f.name)) LOG.error("Feature " + f.name + " threw an error (disabled)", t);
                f.enabled = false;
            }
        }
        try {
            FullbrightFeature.update();
        } catch (Throwable t) {
            LOG.error("Fullbright error", t);
        }
    }

    public static void save() {
        try {
            ClickGui.syncLayout();
            JsonObject root = new JsonObject();
            JsonObject mods = new JsonObject();
            for (Feature f : ALL) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", f.enabled);
                JsonObject s = new JsonObject();
                for (Setting st : f.settings) {
                    if (st instanceof Setting.Bool b) s.addProperty(b.name, b.value);
                    else if (st instanceof Setting.Num n) s.addProperty(n.name, n.value);
                }
                o.add("settings", s);
                mods.add(f.name, o);
            }
            root.add("features", mods);
            JsonArray sell = new JsonArray();
            for (String id : AutoSellFeature.ITEMS) sell.add(id);
            root.add("autosell", sell);
            JsonObject layout = new JsonObject();
            for (var e : ClickGui.LAYOUT.entrySet()) {
                JsonArray a = new JsonArray();
                for (int v : e.getValue()) a.add(v);
                layout.add(e.getKey(), a);
            }
            root.add("layout", layout);
            Files.writeString(file(), GSON.toJson(root));
        } catch (Throwable t) {
            LOG.error("Could not save config", t);
        }
    }

    public static void load() {
        try {
            Path p = file();
            if (!Files.exists(p)) return;
            JsonObject root = GSON.fromJson(Files.readString(p), JsonObject.class);
            if (root == null) return;
            if (root.has("autosell")) {
                for (JsonElement e : root.getAsJsonArray("autosell")) AutoSellFeature.ITEMS.add(e.getAsString());
            }
            if (root.has("layout")) {
                for (var e : root.getAsJsonObject("layout").entrySet()) {
                    JsonArray a = e.getValue().getAsJsonArray();
                    ClickGui.LAYOUT.put(e.getKey(), new int[] {a.get(0).getAsInt(), a.get(1).getAsInt(), a.get(2).getAsInt()});
                }
            }
            JsonObject mods = root.has("features") ? root.getAsJsonObject("features") : new JsonObject();
            for (Feature f : ALL) {
                if (!mods.has(f.name)) continue;
                JsonObject o = mods.getAsJsonObject(f.name);
                if (o.has("settings")) {
                    JsonObject s = o.getAsJsonObject("settings");
                    for (Setting st : f.settings) {
                        if (!s.has(st.name)) continue;
                        if (st instanceof Setting.Bool b) b.value = s.get(st.name).getAsBoolean();
                        else if (st instanceof Setting.Num n) n.value = Math.max(n.min, Math.min(n.max, s.get(st.name).getAsDouble()));
                    }
                }
                if (o.has("enabled") && o.get("enabled").getAsBoolean()) f.setEnabled(true);
            }
        } catch (Throwable t) {
            LOG.error("Could not load config", t);
        }
    }
}
