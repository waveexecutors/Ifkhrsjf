package dev.enzo.utility.feature;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public abstract class Feature {
    public final String name;
    public final String description;
    public final Category category;
    public boolean enabled;
    public final List<Setting> settings = new ArrayList<>();
    protected final Minecraft mc = Minecraft.getInstance();

    protected Feature(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        if (value) onEnable();
        else onDisable();
    }

    protected Setting.Bool bool(String n, boolean def) {
        Setting.Bool s = new Setting.Bool(n, def);
        settings.add(s);
        return s;
    }

    protected Setting.Num num(String n, double def, double min, double max, double step) {
        Setting.Num s = new Setting.Num(n, def, min, max, step);
        settings.add(s);
        return s;
    }

    protected Setting.Button button(String n, java.util.function.Supplier<String> label, Runnable action) {
        Setting.Button s = new Setting.Button(n, label, action);
        settings.add(s);
        return s;
    }

    public void onEnable() {}

    public void onDisable() {}

    public void onTick() {}

    /** Called by the ClickGUI only when the user (not config loading) switched the feature on. */
    public void onToggledByUser() {}

    /** Short suffix shown in the HUD arraylist. */
    public String info() {
        return null;
    }

    /** Draw HUD content at x,y (left column). Return the height used. */
    public int hud(GuiGraphics g, int x, int y) {
        return 0;
    }
}
