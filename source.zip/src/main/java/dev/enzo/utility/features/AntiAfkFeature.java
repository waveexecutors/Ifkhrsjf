package dev.enzo.utility.features;

import dev.enzo.utility.feature.Category;
import dev.enzo.utility.feature.Feature;
import dev.enzo.utility.feature.Setting;
import java.util.Random;
import net.minecraft.world.InteractionHand;

public class AntiAfkFeature extends Feature {
    private final Setting.Num seconds = num("Interval (s)", 20, 5, 120, 5);
    private final Random rnd = new Random();
    private int timer = 0;
    private boolean jumping = false;

    public AntiAfkFeature() {
        super("Anti AFK", "Swings, turns and jumps now and then so you don't get AFK-kicked.", Category.SMP);
    }

    @Override
    public void onDisable() {
        if (jumping) mc.options.keyJump.setDown(false);
        jumping = false;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.screen != null) return;
        if (jumping) {
            mc.options.keyJump.setDown(false);
            jumping = false;
        }
        if (--timer > 0) return;
        timer = seconds.i() * 20;
        mc.player.swing(InteractionHand.MAIN_HAND);
        mc.player.setYRot(mc.player.getYRot() + (rnd.nextFloat() * 16f - 8f));
        mc.options.keyJump.setDown(true);
        jumping = true;
    }
}
