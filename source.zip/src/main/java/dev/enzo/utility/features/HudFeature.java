package dev.enzo.utility.features;

import dev.enzo.utility.feature.Category;
import dev.enzo.utility.feature.Feature;
import dev.enzo.utility.feature.Setting;
import dev.enzo.utility.util.Chat;
import dev.enzo.utility.util.Draw;
import net.minecraft.client.gui.GuiGraphics;

public class HudFeature extends Feature {
    public static HudFeature I;
    public final Setting.Bool arraylist = bool("Arraylist", true);
    public final Setting.Bool coords = bool("Coordinates", true);

    public HudFeature() {
        super("HUD", "Coordinates (with Nether/Overworld conversion) and an enabled-features list.", Category.MISC);
        I = this;
        enabled = true;
    }

    @Override
    public int hud(GuiGraphics g, int x, int y) {
        if (!coords.value || mc.player == null) return 0;
        int px = (int) Math.floor(mc.player.getX());
        int py = (int) Math.floor(mc.player.getY());
        int pz = (int) Math.floor(mc.player.getZ());
        String dim = Chat.dimension();
        String l1 = "XYZ  " + px + "  " + py + "  " + pz + "  " + mc.player.getDirection().getName();
        String l2 = null;
        if (dim.equals("overworld")) l2 = "Nether  " + Math.floorDiv(px, 8) + "  " + Math.floorDiv(pz, 8);
        else if (dim.equals("the_nether")) l2 = "Overworld  " + px * 8 + "  " + pz * 8;
        int w = Draw.width(l1) + 10;
        if (l2 != null) w = Math.max(w, Draw.width(l2) + 10);
        int h = l2 != null ? 25 : 14;
        Draw.hudBox(g, x, y, w, h);
        Draw.text(g, l1, x + 5, y + 3, Draw.TEXT);
        if (l2 != null) Draw.text(g, l2, x + 5, y + 14, Draw.DIM);
        return h + 4;
    }
}
