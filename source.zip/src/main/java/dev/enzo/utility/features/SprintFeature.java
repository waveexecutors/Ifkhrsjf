package dev.enzo.utility.features;

import dev.enzo.utility.feature.Category;
import dev.enzo.utility.feature.Feature;

public class SprintFeature extends Feature {
    public SprintFeature() {
        super("Auto Sprint", "Sprints automatically while you hold forward.", Category.MISC);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.screen != null) return;
        if (mc.options.keyUp.isDown() && !mc.player.isShiftKeyDown() && !mc.player.horizontalCollision
                && !mc.player.isUsingItem() && mc.player.getFoodData().getFoodLevel() > 6) {
            mc.player.setSprinting(true);
        }
    }
}
