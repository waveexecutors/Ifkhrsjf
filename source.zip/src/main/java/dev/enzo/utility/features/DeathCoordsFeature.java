package dev.enzo.utility.features;

import dev.enzo.utility.feature.Category;
import dev.enzo.utility.feature.Feature;
import dev.enzo.utility.util.Chat;
import dev.enzo.utility.util.Draw;
import net.minecraft.client.gui.GuiGraphics;

public class DeathCoordsFeature extends Feature {
    private boolean wasDead = false;
    private String last = null;

    public DeathCoordsFeature() {
        super("Death Coords", "Prints and remembers where you died.", Category.SMP);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        boolean dead = mc.player.isDeadOrDying();
        if (dead && !wasDead) {
            last = (int) mc.player.getX() + " " + (int) mc.player.getY() + " " + (int) mc.player.getZ() + " (" + Chat.dimension() + ")";
            Chat.info("You died at " + last);
        }
        wasDead = dead;
    }

    @Override
    public int hud(GuiGraphics g, int x, int y) {
        if (last == null) return 0;
        String s = "Last death: " + last;
        Draw.hudBox(g, x, y, Draw.width(s) + 10, 14);
        Draw.text(g, s, x + 5, y + 3, Draw.TEXT);
        return 18;
    }
}
