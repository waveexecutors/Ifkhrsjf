package dev.enzo.utility.features;

import dev.enzo.utility.feature.Category;
import dev.enzo.utility.feature.Feature;
import dev.enzo.utility.feature.Setting;
import dev.enzo.utility.util.Inv;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Items;

public class AutoTotemFeature extends Feature {
    private final Setting.Num delay = num("Delay (ticks)", 5, 1, 20, 1);
    private int timer = 0;

    public AutoTotemFeature() {
        super("Auto Totem", "Keeps a Totem of Undying in your offhand.", Category.AUTOMATION);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.gameMode == null || mc.screen != null) return;
        if (--timer > 0) return;
        if (mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) return;
        int slot = Inv.findInv(s -> s.is(Items.TOTEM_OF_UNDYING));
        if (slot < 0) return;
        mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, Inv.menuSlot(slot), 40, ClickType.SWAP, mc.player);
        timer = delay.i();
    }
}
