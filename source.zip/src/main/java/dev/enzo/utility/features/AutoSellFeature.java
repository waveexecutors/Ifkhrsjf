package dev.enzo.utility.features;

import dev.enzo.utility.feature.Category;
import dev.enzo.utility.feature.Feature;
import dev.enzo.utility.feature.Setting;
import dev.enzo.utility.gui.ItemPickerScreen;
import dev.enzo.utility.util.Inv;
import java.util.LinkedHashSet;
import java.util.Set;
import net.minecraft.world.item.ItemStack;

/**
 * Toggle it on, pick the items in the window that opens, and the mod will keep
 * holding one of those items and sending /sell on a timer.
 */
public class AutoSellFeature extends Feature {
    public static final Set<String> ITEMS = new LinkedHashSet<>();

    private final Setting.Num delay = num("Delay (ticks)", 40, 10, 600, 10);
    private final Setting.Bool sellHand = bool("Use '/sell hand'", false);

    private int cooldown = 0;
    private int stage = 0;

    public AutoSellFeature() {
        super("Auto Sell", "Pick items from your inventory; they get sold automatically with /sell.", Category.AUTOMATION);
        button("Items", () -> "Choose items... (" + ITEMS.size() + ")", this::openPicker);
    }

    private void openPicker() {
        if (mc.player != null) mc.setScreen(new ItemPickerScreen(mc.screen));
    }

    @Override
    public void onToggledByUser() {
        openPicker();
    }

    @Override
    public void onDisable() {
        stage = 0;
        cooldown = 0;
    }

    @Override
    public String info() {
        return ITEMS.size() + " item(s)";
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.gameMode == null || mc.screen != null || ITEMS.isEmpty()) return;
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        if (stage == 0) {
            int slot = Inv.findInv(st -> ITEMS.contains(Inv.id(st)));
            if (slot < 0) {
                cooldown = 20;
                return;
            }
            if (slot < 9) Inv.select(slot);
            else Inv.swap(slot, Inv.selected());
            stage = 1;
            cooldown = 2;
        } else {
            ItemStack held = mc.player.getMainHandItem();
            if (!held.isEmpty() && ITEMS.contains(Inv.id(held))) {
                mc.player.connection.sendCommand(sellHand.value ? "sell hand" : "sell");
            }
            stage = 0;
            cooldown = delay.i();
        }
    }
}
