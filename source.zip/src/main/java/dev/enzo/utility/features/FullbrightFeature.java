package dev.enzo.utility.features;

import dev.enzo.utility.feature.Category;
import dev.enzo.utility.feature.Feature;
import net.minecraft.client.Minecraft;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

public class FullbrightFeature extends Feature {
    private static FullbrightFeature self;
    private static boolean added = false;

    public FullbrightFeature() {
        super("Fullbright", "Client-side night vision so caves and ores are always bright.", Category.RENDER);
        self = this;
    }

    /** Called every tick (even when this feature is off) so Xray can request light too. */
    public static void update() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            added = false;
            return;
        }
        boolean want = (self != null && self.enabled)
                || (XrayFeature.I != null && XrayFeature.I.enabled && XrayFeature.I.fullbright.value);
        boolean has = mc.player.hasEffect(MobEffects.NIGHT_VISION);
        if (want && !has) {
            mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 1_000_000, 0, false, false));
            added = true;
        } else if (!want && added) {
            mc.player.removeEffect(MobEffects.NIGHT_VISION);
            added = false;
        }
    }
}
