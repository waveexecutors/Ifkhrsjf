package dev.enzo.utility.features;

import dev.enzo.utility.feature.Category;
import dev.enzo.utility.feature.Feature;
import dev.enzo.utility.feature.Setting;
import dev.enzo.utility.util.Draw;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Scans loaded blocks around you and lists ores that are touching air/fluid.
 * Because it only reports EXPOSED ores, it ignores the fake ores that anti-xray
 * servers (Paper engine-mode 2) hide inside solid rock.
 */
public class OreFinderFeature extends Feature {
    private final Setting.Num range = num("Range", 24, 8, 48, 4);
    private final Setting.Num interval = num("Scan Interval (ticks)", 40, 10, 200, 10);
    private final Setting.Bool exposedOnly = bool("Exposed Only", true);
    private final Setting.Bool common = bool("Coal / Iron / Copper", false);

    private record Hit(BlockPos pos, String name, double dist) {}

    private final Map<Block, Integer> cache = new HashMap<>();
    private volatile List<Hit> hits = List.of();
    private int timer = 0;

    public OreFinderFeature() {
        super("Ore Finder", "Lists nearby ores that are exposed (ignores anti-xray fake ores).", Category.RENDER);
    }

    @Override
    public void onDisable() {
        hits = List.of();
    }

    @Override
    public String info() {
        return String.valueOf(hits.size());
    }

    private int interest(Block b) {
        Integer c = cache.get(b);
        if (c != null) return c;
        String p = BuiltInRegistries.BLOCK.getKey(b).getPath();
        int v = 0;
        if (p.equals("ancient_debris") || p.endsWith("_ore")) {
            if (p.contains("coal") || p.contains("iron") || p.contains("copper")) v = 1;
            else v = 2;
        }
        cache.put(b, v);
        return v;
    }

    @Override
    public void onTick() {
        if (--timer > 0) return;
        timer = interval.i();
        scan();
    }

    private void scan() {
        if (mc.player == null || mc.level == null) return;
        BlockPos c = mc.player.blockPosition();
        int r = range.i();
        List<Hit> out = new ArrayList<>();
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        BlockPos.MutableBlockPos np = new BlockPos.MutableBlockPos();
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    mp.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                    BlockState s = mc.level.getBlockState(mp);
                    if (s.isAir()) continue;
                    int in = interest(s.getBlock());
                    if (in == 0 || (in == 1 && !common.value)) continue;
                    if (exposedOnly.value) {
                        boolean exposed = false;
                        for (Direction d : Direction.values()) {
                            np.set(mp.getX() + d.getStepX(), mp.getY() + d.getStepY(), mp.getZ() + d.getStepZ());
                            BlockState n = mc.level.getBlockState(np);
                            if (n.isAir() || !n.getFluidState().isEmpty()) {
                                exposed = true;
                                break;
                            }
                        }
                        if (!exposed) continue;
                    }
                    String path = BuiltInRegistries.BLOCK.getKey(s.getBlock()).getPath();
                    out.add(new Hit(mp.immutable(), Draw.pretty(path), Math.sqrt(mp.distSqr(c))));
                    if (out.size() > 400) break;
                }
            }
        }
        out.sort(Comparator.comparingDouble(Hit::dist));
        hits = out.size() > 8 ? new ArrayList<>(out.subList(0, 8)) : out;
    }

    @Override
    public int hud(GuiGraphics g, int x, int y) {
        List<Hit> h = hits;
        int lines = Math.max(1, h.size()) + 1;
        int w = 160;
        for (Hit hit : h) w = Math.max(w, Draw.width(line(hit)) + 10);
        Draw.hudBox(g, x, y, w, lines * 11 + 3);
        Draw.text(g, "Ore Finder (" + h.size() + ")", x + 5, y + 3, Draw.ACCENT);
        int yy = y + 14;
        if (h.isEmpty()) Draw.text(g, "nothing exposed nearby", x + 5, yy, Draw.DIM);
        for (Hit hit : h) {
            Draw.text(g, line(hit), x + 5, yy, Draw.TEXT);
            yy += 11;
        }
        return lines * 11 + 7;
    }

    private String line(Hit h) {
        return h.name() + "  " + h.pos().getX() + " " + h.pos().getY() + " " + h.pos().getZ() + "  " + (int) h.dist() + "m";
    }
}
