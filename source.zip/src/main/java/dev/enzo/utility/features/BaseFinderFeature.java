package dev.enzo.utility.features;

import dev.enzo.utility.feature.Category;
import dev.enzo.utility.feature.Feature;
import dev.enzo.utility.feature.Setting;
import dev.enzo.utility.util.Chat;
import dev.enzo.utility.util.Draw;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.status.ChunkStatus;

/**
 * Scores every loaded chunk by player-made block entities (chests, hoppers, furnaces,
 * beds, shulkers...) plus man-made block hints, then lists the best candidates.
 * Only chunks your client has loaded can be scanned. Villages/structures can score too.
 */
public class BaseFinderFeature extends Feature {
    private final Setting.Num threshold = num("Min Score", 12, 3, 60, 1);
    private final Setting.Num interval = num("Scan Interval (s)", 5, 1, 30, 1);
    private final Setting.Bool alerts = bool("Chat Alerts", true);

    public record Found(int x, int z, int score) {}

    private final Map<Block, Boolean> manMadeCache = new HashMap<>();
    private final Set<Long> notified = new HashSet<>();
    private volatile List<Found> found = List.of();
    private int timer = 0;

    public BaseFinderFeature() {
        super("Base Finder", "Finds chunks with lots of chests, hoppers, furnaces, beds... (player bases).", Category.SMP);
    }

    @Override
    public void onDisable() {
        found = List.of();
        notified.clear();
    }

    @Override
    public String info() {
        return String.valueOf(found.size());
    }

    @Override
    public void onTick() {
        if (--timer > 0) return;
        timer = interval.i() * 20;
        scan();
    }

    private int weight(BlockEntity be) {
        String p = BuiltInRegistries.BLOCK.getKey(be.getBlockState().getBlock()).getPath();
        if (p.contains("shulker")) return 5;
        if (p.equals("beacon")) return 6;
        if (p.equals("hopper")) return 4;
        if (p.equals("ender_chest")) return 3;
        if (p.contains("chest") || p.equals("barrel") || p.equals("crafter")) return 3;
        if (p.endsWith("furnace") || p.equals("smoker") || p.endsWith("_bed") || p.equals("brewing_stand")
                || p.equals("dispenser") || p.equals("dropper") || p.equals("jukebox") || p.equals("enchanting_table")) return 2;
        if (p.contains("sign") || p.equals("lectern")) return 1;
        return 0;
    }

    private boolean manMade(BlockState s) {
        Block b = s.getBlock();
        Boolean c = manMadeCache.get(b);
        if (c != null) return c;
        String p = BuiltInRegistries.BLOCK.getKey(b).getPath();
        boolean v = p.contains("concrete") || p.endsWith("_wool") || p.equals("glass") || p.contains("stained_glass")
                || p.startsWith("stripped_") || p.equals("crafting_table") || p.equals("bookshelf") || p.contains("lantern")
                || p.endsWith("_carpet") || p.contains("polished_") && !p.contains("andesite") && !p.contains("diorite") && !p.contains("granite");
        manMadeCache.put(b, v);
        return v;
    }

    private void scan() {
        if (mc.player == null || mc.level == null) return;
        int rd = Math.min(mc.options.renderDistance().get(), 24);
        int pcx = mc.player.blockPosition().getX() >> 4;
        int pcz = mc.player.blockPosition().getZ() >> 4;
        int min = threshold.i();
        List<Found> out = new ArrayList<>();
        for (int cx = pcx - rd; cx <= pcx + rd; cx++) {
            for (int cz = pcz - rd; cz <= pcz + rd; cz++) {
                ChunkAccess ca = mc.level.getChunk(cx, cz, ChunkStatus.FULL, false);
                if (!(ca instanceof LevelChunk chunk)) continue;
                int score = 0;
                for (BlockEntity be : chunk.getBlockEntities().values()) score += weight(be);
                for (LevelChunkSection sec : chunk.getSections()) {
                    if (sec.hasOnlyAir()) continue;
                    if (sec.getStates().maybeHas(this::manMade)) score++;
                }
                if (score >= min) out.add(new Found(cx * 16 + 8, cz * 16 + 8, score));
            }
        }
        out.sort(Comparator.comparingInt(Found::score).reversed());
        if (alerts.value) {
            for (Found f : out) {
                long key = ((long) (f.x() >> 4) << 32) | ((f.z() >> 4) & 0xFFFFFFFFL);
                if (notified.add(key)) {
                    Chat.info("Possible base near X " + f.x() + " Z " + f.z() + " (score " + f.score() + ")");
                }
            }
        }
        found = out.size() > 6 ? new ArrayList<>(out.subList(0, 6)) : out;
    }

    @Override
    public int hud(GuiGraphics g, int x, int y) {
        List<Found> f = found;
        int lines = Math.max(1, f.size()) + 1;
        Draw.hudBox(g, x, y, 190, lines * 11 + 3);
        Draw.text(g, "Base Finder (" + f.size() + ")", x + 5, y + 3, Draw.ACCENT);
        int yy = y + 14;
        if (f.isEmpty()) Draw.text(g, "no bases in loaded chunks", x + 5, yy, Draw.DIM);
        for (Found b : f) {
            double d = 0;
            if (mc.player != null) {
                double dx = b.x() - mc.player.getX(), dz = b.z() - mc.player.getZ();
                d = Math.sqrt(dx * dx + dz * dz);
            }
            Draw.text(g, "X " + b.x() + "  Z " + b.z() + "  score " + b.score() + "  " + (int) d + "m", x + 5, yy, Draw.TEXT);
            yy += 11;
        }
        return lines * 11 + 7;
    }
}
