package dev.enzo.utility.features;

import dev.enzo.utility.feature.Category;
import dev.enzo.utility.feature.Feature;
import dev.enzo.utility.feature.Setting;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public class XrayFeature extends Feature {
    public static volatile boolean active = false;
    private static volatile Set<Block> visible = new HashSet<>();
    public static XrayFeature I;

    private final Setting.Bool ores = bool("Ores", true);
    private final Setting.Bool debris = bool("Ancient Debris", true);
    private final Setting.Bool storage = bool("Chests / Storage", false);
    private final Setting.Bool spawners = bool("Spawners / Vaults", false);
    private final Setting.Bool manmade = bool("Base Hints (torches, doors...)", false);
    public final Setting.Bool fullbright = bool("Fullbright", true);

    public XrayFeature() {
        super("Xray", "Hides every block except the ones you pick so ores show through stone.", Category.RENDER);
        I = this;
        for (Setting s : settings) s.onChange = this::refresh;
    }

    @Override
    public void onEnable() {
        rebuild();
        active = true;
        reload();
    }

    @Override
    public void onDisable() {
        active = false;
        reload();
    }

    private void refresh() {
        if (enabled) {
            rebuild();
            reload();
        }
    }

    private void reload() {
        if (mc.level != null && mc.levelRenderer != null) {
            mc.levelRenderer.allChanged();
        }
    }

    private void rebuild() {
        Set<Block> s = new HashSet<>();
        for (Block b : BuiltInRegistries.BLOCK) {
            String p = BuiltInRegistries.BLOCK.getKey(b).getPath();
            if (match(p)) s.add(b);
        }
        visible = s;
    }

    private boolean match(String p) {
        if (ores.value && p.endsWith("_ore")) return true;
        if (debris.value && p.equals("ancient_debris")) return true;
        if (storage.value && (p.equals("chest") || p.equals("trapped_chest") || p.equals("ender_chest") || p.equals("barrel")
                || p.endsWith("shulker_box") || p.endsWith("furnace") || p.equals("smoker") || p.equals("hopper")
                || p.equals("crafter") || p.equals("dispenser") || p.equals("dropper"))) return true;
        if (spawners.value && (p.equals("spawner") || p.equals("trial_spawner") || p.equals("vault"))) return true;
        if (manmade.value && (p.contains("torch") || p.contains("lantern") || p.endsWith("_door") || p.endsWith("planks")
                || p.equals("glass") || p.endsWith("_bed") || p.equals("ladder") || p.endsWith("rail") || p.equals("tnt")
                || p.equals("crafting_table") || p.equals("bookshelf"))) return true;
        return false;
    }

    public static boolean isHidden(BlockState s) {
        return !s.isAir() && !visible.contains(s.getBlock());
    }
}
