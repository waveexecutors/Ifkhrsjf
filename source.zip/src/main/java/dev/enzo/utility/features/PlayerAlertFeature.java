package dev.enzo.utility.features;

import dev.enzo.utility.feature.Category;
import dev.enzo.utility.feature.Feature;
import dev.enzo.utility.util.Chat;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class PlayerAlertFeature extends Feature {
    private final Set<UUID> known = new HashSet<>();
    private int timer = 0;

    public PlayerAlertFeature() {
        super("Player Alert", "Chat alert when another player comes into render distance.", Category.SMP);
    }

    @Override
    public void onDisable() {
        known.clear();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) return;
        if (--timer > 0) return;
        timer = 10;
        Set<UUID> now = new HashSet<>();
        for (var p : mc.level.players()) {
            if (p == mc.player) continue;
            UUID id = p.getUUID();
            now.add(id);
            if (known.add(id)) {
                Chat.info(p.getName().getString() + " entered render distance (" + (int) p.distanceTo(mc.player) + " blocks)");
            }
        }
        known.retainAll(now);
    }
}
