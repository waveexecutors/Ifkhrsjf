package dev.enzo.utility.features;

import dev.enzo.utility.feature.Category;
import dev.enzo.utility.feature.Feature;
import dev.enzo.utility.feature.Setting;
import dev.enzo.utility.util.Inv;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.NetherWartBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Harvests fully grown crops around you, replants them, and (optionally) acts as a
 * "farm maker": tills dirt/grass with a hoe from your hotbar and plants seeds on it.
 * Needs seeds (and a hoe for the maker) in the hotbar. Water is up to you.
 */
public class AutoFarmFeature extends Feature {
    private final Setting.Num range = num("Range", 4, 1, 4, 1);
    private final Setting.Num delay = num("Delay (ticks)", 2, 1, 10, 1);
    private final Setting.Bool harvest = bool("Harvest", true);
    private final Setting.Bool replant = bool("Replant", true);
    private final Setting.Bool maker = bool("Farm Maker (till + plant)", false);

    private int timer = 0;
    private Block lastCrop = Blocks.WHEAT;

    public AutoFarmFeature() {
        super("Auto Farm", "Harvests + replants crops nearby. Farm Maker tills dirt and plants seeds.", Category.AUTOMATION);
    }

    private boolean mature(BlockState s) {
        Block b = s.getBlock();
        if (b instanceof CropBlock cb) return cb.isMaxAge(s);
        if (b == Blocks.NETHER_WART) return s.getValue(NetherWartBlock.AGE) >= 3;
        return false;
    }

    private Item seedFor(Block crop) {
        if (crop == Blocks.CARROTS) return Items.CARROT;
        if (crop == Blocks.POTATOES) return Items.POTATO;
        if (crop == Blocks.BEETROOTS) return Items.BEETROOT_SEEDS;
        return Items.WHEAT_SEEDS;
    }

    private boolean farmlandSeed(ItemStack s) {
        return s.is(Items.WHEAT_SEEDS) || s.is(Items.CARROT) || s.is(Items.POTATO) || s.is(Items.BEETROOT_SEEDS);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null || mc.gameMode == null || mc.screen != null) return;
        if (--timer > 0) return;
        timer = delay.i();

        int r = range.i();
        BlockPos c = mc.player.blockPosition();
        Vec3 eye = mc.player.getEyePosition();

        BlockPos harvestPos = null, plantPos = null, wartPos = null, tillPos = null;
        double hd = 1e9, pd = 1e9, wd = 1e9, td = 1e9;

        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -2; dy <= 1; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    BlockPos p = c.offset(dx, dy, dz);
                    double d = eye.distanceToSqr(Vec3.atCenterOf(p));
                    if (d > 20.0) continue;
                    BlockState s = mc.level.getBlockState(p);
                    if (harvest.value && mature(s)) {
                        if (d < hd) { hd = d; harvestPos = p; }
                        continue;
                    }
                    if (!mc.level.getBlockState(p.above()).isAir()) continue;
                    if (replant.value) {
                        if (s.is(Blocks.FARMLAND) && d < pd) { pd = d; plantPos = p; }
                        else if (s.is(Blocks.SOUL_SAND) && d < wd) { wd = d; wartPos = p; }
                    }
                    if (maker.value && (s.is(Blocks.DIRT) || s.is(Blocks.GRASS_BLOCK) || s.is(Blocks.DIRT_PATH)) && d < td) {
                        td = d;
                        tillPos = p;
                    }
                }
            }
        }

        if (harvestPos != null) {
            lastCrop = mc.level.getBlockState(harvestPos).getBlock();
            mc.gameMode.startDestroyBlock(harvestPos, Direction.UP);
            mc.player.swing(InteractionHand.MAIN_HAND);
            return;
        }

        if (plantPos != null) {
            final Item want = seedFor(lastCrop);
            int slot = Inv.findHotbar(st -> st.is(want));
            if (slot < 0) slot = Inv.findHotbar(this::farmlandSeed);
            if (slot >= 0) {
                Inv.select(slot);
                Inv.useOnTop(plantPos);
                return;
            }
        }

        if (wartPos != null) {
            int slot = Inv.findHotbar(st -> st.is(Items.NETHER_WART));
            if (slot >= 0) {
                Inv.select(slot);
                Inv.useOnTop(wartPos);
                return;
            }
        }

        if (tillPos != null) {
            int slot = Inv.findHotbar(st -> st.is(ItemTags.HOES));
            if (slot >= 0) {
                Inv.select(slot);
                Inv.useOnTop(tillPos);
            }
        }
    }
}
