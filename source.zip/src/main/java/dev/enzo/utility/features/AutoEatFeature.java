package dev.enzo.utility.features;

import dev.enzo.utility.feature.Category;
import dev.enzo.utility.feature.Feature;
import dev.enzo.utility.feature.Setting;
import dev.enzo.utility.util.Inv;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.ItemStack;

public class AutoEatFeature extends Feature {
    private final Setting.Num hunger = num("Eat At Food <=", 14, 1, 19, 1);

    private boolean eating = false;
    private int prevSlot = -1;
    private int idle = 0;

    public AutoEatFeature() {
        super("Auto Eat", "Eats the best food from your hotbar when hungry.", Category.AUTOMATION);
    }

    @Override
    public void onDisable() {
        stop();
    }

    private boolean goodFood(ItemStack s) {
        if (!s.has(DataComponents.FOOD)) return false;
        String p = BuiltInRegistries.ITEM.getKey(s.getItem()).getPath();
        return !(p.equals("rotten_flesh") || p.equals("spider_eye") || p.equals("poisonous_potato") || p.equals("pufferfish")
                || p.equals("chorus_fruit") || p.equals("suspicious_stew") || p.equals("raw_chicken") || p.equals("chicken"));
    }

    private int nutrition(ItemStack s) {
        var f = s.get(DataComponents.FOOD);
        return f == null ? 0 : f.nutrition();
    }

    private void stop() {
        if (eating) {
            mc.options.keyUse.setDown(false);
            if (prevSlot >= 0 && mc.player != null) Inv.select(prevSlot);
        }
        eating = false;
        prevSlot = -1;
        idle = 0;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.screen != null) {
            stop();
            return;
        }
        int food = mc.player.getFoodData().getFoodLevel();
        if (eating) {
            if (food > hunger.i()) {
                stop();
                return;
            }
            if (mc.player.isUsingItem()) idle = 0;
            else if (++idle > 25) {
                stop();
                return;
            }
            mc.options.keyUse.setDown(true);
            return;
        }
        if (food > hunger.i()) return;
        int best = -1, bestN = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getItem(i);
            if (!s.isEmpty() && goodFood(s) && nutrition(s) > bestN) {
                bestN = nutrition(s);
                best = i;
            }
        }
        if (best < 0) return;
        prevSlot = Inv.selected();
        Inv.select(best);
        eating = true;
        idle = 0;
        mc.options.keyUse.setDown(true);
    }
}
