package dev.enzo.utility;

import dev.enzo.utility.feature.Features;
import dev.enzo.utility.gui.ClickGui;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.lwjgl.glfw.GLFW;

public class EnzoUtility implements ClientModInitializer {
    private boolean rsPrev = false;

    @Override
    public void onInitializeClient() {
        Features.init();
        Features.load();

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            long win = GLFW.glfwGetCurrentContext();
            boolean down = win != 0L && GLFW.glfwGetKey(win, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
            if (down && !rsPrev && mc.screen == null && mc.level != null) {
                mc.setScreen(new ClickGui());
            }
            rsPrev = down;
            if (mc.player != null && mc.level != null) {
                Features.tick();
            }
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> Features.save());
    }
}
