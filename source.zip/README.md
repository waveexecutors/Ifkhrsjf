# Pizza Client

Premium Fabric utility client for Minecraft 1.21.x.

## Features

- **3D Xray** – true depth Xray that hides non-interesting blocks
- **2D ESP** – player boxes, distance & health tags
- **Tracers** – lines to players
- **Bhop** – highly configurable bunny hop (speed, height, lowhop, timer)
- **AntiKick** – AFK / movement kick protection
- **AntiLag** – particle & entity load reduction
- **FPS Cap** – configurable framerate limiter
- Fullbright, Sprint, AutoEat, AutoTotem, AutoFarm, AutoSell
- OreFinder, BaseFinder, PlayerAlert, DeathCoords
- Premium Vape-style ClickGUI + polished HUD

## Controls

- **Right Shift** – open / close ClickGUI
- Left click – toggle module
- Right click – expand settings
- Drag panel headers to move

## Build

```bash
./gradlew build
```

Jar appears in `build/libs/`.
