# Enzo Utility (Fabric 1.21.11)
Right Shift = ClickGUI. Build on GitHub Actions (see build.yml). Config: .minecraft/config/enzoutility.json
